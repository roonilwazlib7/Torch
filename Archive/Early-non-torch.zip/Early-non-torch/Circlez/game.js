$(document).ready(function()
{
    var pipin = new Pipin("gameCanvas");
    window["pipin"] = pipin;
    var player = new Player();

    var Load = function()
    {
        Loader.Load();
    };

    var Draw = function()
    {
        player.Draw();
    };

    var Update = function()
    {
        player.Update();
    };

    var game = new Pipin.Game(pipin, Load, Draw, Update);
    pipin.LoadGame(game);
    pipin.Run();

    window["player"] = player;
});

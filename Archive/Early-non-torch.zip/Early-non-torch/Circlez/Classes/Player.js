(function()
{

    var Player = new Class(function()
    {
        ;"Player";
        this.bodyCircle = {
            x: (pipin.Viewport.width / 2),
            y: (pipin.Viewport.height / 2),
            r: 100
        }

        var that = this;
        var x = that.bodyCircle.x;
        var y = that.bodyCircle.y;
        var r = that.bodyCircle.r;

        that.redCircle = {x: x - 200, y: y + r /3, o:Math.PI, color:"red"};
        that.yellowCircle = {x: x + 200, y: y + r /3, o:0, color: "yellow"};
        that.blueCircle = {x: x - r/3, y: y - 200, o:Math.PI / 2, color:"blue"};

        that.redCircle.ox = that.redCircle.x;
        that.redCircle.oy = that.redCircle.y;

        this.lockRedCounter = 0;
        this.lockBlueCounter = 0;
        this.lockYellowCounter - 0;

        this.lockColorSwitchCounter = 0;
        this.lockColorSwitch = false;

        this.t = 0;
        this.orbitCircles = [that.redCircle, that.blueCircle, that.yellowCircle];
        this.color = "black";
        this.cr = 95;
        this.cg = 100;
        this.cb = 34;

        this.convergingOrbits = false;
        this.trigger = false;
        this.unlockConvergingOrbitsCounter = 0;


    });
//fix
    Player.Prop("lockRed", false);
    Player.Prop("lockBlue", false);
    Player.Prop("lockYellow", false);

    Player.Prop("bodyCircle", {
    });

    Player.Prop("redCircle", {});
    Player.Prop("blueCircle", {});
    Player.Prop("yellowCircle", {});

    Player.Prop("DrawOrbitCircles", function()
    {
        var that = this;
        for (var i = 0; i < that.orbitCircles.length; i++)
        {
            var circ = that.orbitCircles[i];
            pipin.DrawCircle(circ.x, circ.y,10, circ.color);
        }

    });

    Player.Prop("UpdateMoveOrbitCircles", function(){
        var that = this;
        that.t += 0.05;
        var A = 200;
        if (that.convergingOrbits)
        {
            return;
        }
        for (var i = 0; i < that.orbitCircles.length; i++)
        {
            var circ = that.orbitCircles[i];
            var transX = A * Math.cos(that.t + circ.o);
            var transY = A * Math.sin(that.t + circ.o);

            circ.x = transX + that.bodyCircle.x;
            circ.y = transY + that.bodyCircle.y;
        }



    });

    Player.Prop("UpdateCheckMouse", function()
    {
        var that = this;
        if (pipin.Mouse.down)
        {
            this.trigger = true;
        }
        if (!pipin.Mouse.down && this.trigger)
        {
            this.trigger = false;
            this.convergingOrbits = true;
            for (var i = 0; i < that.orbitCircles.length; i++)
            {
                that.orbitCircles[i].ox = that.orbitCircles[i].x;
                that.orbitCircles[i].oy = that.orbitCircles[i].y;
                var rAnim = new Pipin.Animation.LinearObjectAnimation(that.orbitCircles[i], {x: pipin.Mouse.x, y: pipin.Mouse.y}, 500, function(){});
                rAnim.Single();
            }
        }
        if (that.convergingOrbits)
        {
            that.unlockConvergingOrbitsCounter += pipin.deltaTime;
            if (that.unlockConvergingOrbitsCounter >= 500)
            {

                for (var i = 0; i < that.orbitCircles.length; i++)
                {
                    //need to adjust the angle when moving back
                    var rAnim = new Pipin.Animation.LinearObjectAnimation(that.orbitCircles[i], {x: that.orbitCircles[i].ox, y: that.orbitCircles[i].oy}, 1000, function(){});
                    rAnim.Single();
                }

            }
            if (that.unlockConvergingOrbitsCounter >= 1400)
            {
                that.unlockConvergingOrbitsCounter = 0;
                that.convergingOrbits = false;
            }
        }
    });

    Player.Prop("UpdateColorSwitch", function()
    {
        var that = this;
        that.lockColorSwitchCounter += pipin.deltaTime;
        if (that.lockColorSwitchCounter >= 5000)
        {
            that.lockColorSwitch = false;
        }
        if (!that.lockColorSwitch)
        {
            that.AnimateColorSwitch();
        }
    });

    Player.Prop("AnimateColorSwitch", function()
    {
        var that = this;
        that.lockColorSwitch = true;
        that.lockColorSwitchCounter = 0;
        var cr = Math.floor(Math.random() * 256);
        var cb = Math.floor(Math.random() * 256);
        var cg = Math.floor(Math.random() * 256);

        var anim = new Pipin.Animation.LinearObjectAnimation(that, {cr:cr,cb:cb,cg:cg}, 1000, function(){}, true);
        anim.Single();
    });


    Player.Prop("Load", function()
    {
        var that = this;
        Player.Assets = {};
    });

    Player.Prop("Draw", function()
    {
        var that = this;
        pipin.DrawCircle(that.bodyCircle.x, that.bodyCircle.y, that.bodyCircle.r, "rgb(" + that.cr + "," + that.cg + "," + that.cb + ")");
        that.DrawOrbitCircles();
    });

    Player.Prop("Update", function()
    {
        var that = this;
        that.UpdateColorSwitch();
        that.UpdateMoveOrbitCircles();
        that.UpdateCheckMouse();
    });

    window["Player"] = Player;

})();

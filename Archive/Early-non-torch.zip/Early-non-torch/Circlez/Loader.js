var Loader = new Pipin.Loader([
    ["logo", function(){}],
    ["Player", Player.Static.Load]
],"0.0.1", "logo.png");

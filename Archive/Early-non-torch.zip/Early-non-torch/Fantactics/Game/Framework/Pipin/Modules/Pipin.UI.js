Pipin.UI = {};
(function()
{
    var UI = new Class(function()
    {
        ;"UI";
    });

    UI.Prop("mouseDownTrigger", false);

    UI.Prop("Rectangle", null);
    UI.Prop("DrawTexture", null);

    UI.Prop("OnClick", function(){});
    UI.Prop("OnMouseDown", function(){});
    UI.Prop("OnMouseUp", function(){});
    UI.Prop("OnMouseOver", function(){});
    UI.Prop("OnMouseLeave", function(){});

    UI.Prop("UpdateCheckClick", function()
    {
        var that = this;
        if (pipin.Mouse.up && that.mouseDownTrigger)
        {
            that.OnClick();
            that.mouseDownTrigger = false;
        }
    });

    UI.Prop("UpdateCheckMouseDown", function()
    {
        var that = this;
        if (pipin.Mouse.down)
        {
            that.mouseDownTrigger = true;
            that.OnMouseDown();
        }
    });

    UI.Prop("UpdateCheckMouseUp", function()
    {
        var that = this;
        if (pipin.Mouse.up && that.mouseDownTrigger)
        {
            that.OnMouseUp();
            that.mouseDownTrigger = false;
        }
    });

    UI.Prop("UpdateCheckMouseOver", function()
    {
        var that = this;
        if (that.Rectangle.Intersects(pipin.Mouse.GetRectangle()))
        {
            that.OnMouseOver();
        }
    });

    UI.Prop("UpdateCheckMouseLeave", function()
    {
        var that = this;
    });

    UI.Prop("Load", function()
    {
        var that = this;
        UI.Assets = {};
        UI.Assets.def_background = pipin.LoadTexture("../Game/Framework/Pipin/Assets/def_background_texture.png");
        UI.Assets.def_foreground = pipin.LoadTexture("../Game/Framework/Pipin/Assets/def_foreground_texture.png");
        UI.Assets.def_hover_background = pipin.LoadTexture("../Game/Framework/Pipin/Assets/def_hover_background_texture.png");
        UI.Assets.def_active_background = pipin.LoadTexture("../Game/Framework/Pipin/Assets/def_active_background_texture.png");
    });

    UI.Prop("Draw", function()
    {
        var that = this;
    });

    UI.Prop("Update", function()
    {
        var that = this;
    });

    Pipin.UI.UI = UI;

})();

(function()
{
    var Button = new Class(function()
    {
        ;"Button";
    });

    Button.Inherits(Pipin.UI.UI);
})();

(function(){

	var GameObject = new Class(function(){
		;"GameObject";
	});

	var //public non-functions
		Rectangle = {},
		DrawTexture = {},
		DrawParams = {};

	var //public functions
		Load = function(){},
		Draw = function(){
			var that = this;
			pipin.Draw(that.DrawTexture, that.Rectangle, that.DrawParams);
		},
		Update = function(){};

	GameObject.Properties({
		Rectangle:Rectangle,
		DrawTexture:DrawTexture,
		DrawParams:DrawParams,

		Load:Load,
		Draw:Draw,
		Update:Update
	});

	window["GameObject"] = GameObject;

})();




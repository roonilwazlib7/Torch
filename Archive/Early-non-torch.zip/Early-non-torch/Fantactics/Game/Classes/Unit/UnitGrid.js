/*
* Split all Comples-ish grid tranversal functions for unit
*/

(function(){
    var UnitGrid = new Class(function()
    {
        ;"UnitGrid";
    });

    UnitGrid.Prop("AreAllMovesTheSame", function(moveList)
    {
        var that = this;
        var firstElem = moveList[0];
        for (var i = 0; i < moveList.length; i++)
        {
            if (moveList[i] != firstElem)
            {
                return false;
            }
        }
        return true;
    });

    UnitGrid.Prop("CheckForComplexPaths", function(failedMovePath)
    {
        var that = this;
        var repeatedMove = "";
        var op1 = "";
        var op2 = "";
        if (that.AreAllMovesTheSame(failedMovePath))
        {
            repeatedMove = failedMovePath[0];
            if (repeatedMove == "l" || repeatedMove == "r")
            {
                op1 = "u";
                op2 = "d";
            }
            else
            {
                op1 = "r";
                op2 = "l";
            }
            failedMovePath.pop();
            var complexPattern = failedMovePath.concat([op1,op2,repeatedMove]);
            var perms = Global.permutator(complexPattern);
            for (var i = 0; i < perms.length; i++)
            {
                if (that.AbsoluteValidatePath(perms[i]) && perms[i].length <= that.movesToGo)
                {
                    return true;
                }
            }
            return false;
        }
    });

    UnitGrid.Prop("ValidatePath", function(path)
    {
        //Needs to be fixed!!!
        var that = this;
        var dH = 0;
        var dV = 0;
        for (var i = 0; i < path.length; i++)
        {
            var checkCell;
            switch (path[i])
            {
                case "l":
                    dH--;
                    checkCell = that.grid.GetCell(that.locationCell.Row + dH, that.locationCell.Column + dV);
                    if (checkCell.HasUnit)
                    {
                        return that.CheckForComplexPaths(path);
                    }
                break;
                case "r":
                    dH++;
                    checkCell = that.grid.GetCell(that.locationCell.Row + dH, that.locationCell.Column + dV);
                    if (checkCell.HasUnit)
                    {
                        return that.CheckForComplexPaths(path);
                    }
                break;
                case "u":
                    dV--;
                    checkCell = that.grid.GetCell(that.locationCell.Row + dH, that.locationCell.Column + dV);
                    if (checkCell.HasUnit)
                    {
                        return that.CheckForComplexPaths(path);
                    }
                break;
                case "d":
                    dV++;
                    checkCell = that.grid.GetCell(that.locationCell.Row + dH, that.locationCell.Column + dV);
                    if (checkCell.HasUnit)
                    {
                        return that.CheckForComplexPaths(path);
                    }
                break;

            }
        }
        return true;
    });

    UnitGrid.Prop("AbsoluteValidatePath", function(path)
    {
        //Needs to be fixed!!!
        var that = this;
        var dH = 0;
        var dV = 0;
        for (var i = 0; i < path.length; i++)
        {
            var checkCell;
            switch (path[i])
            {
                case "l":
                    dH--;
                    checkCell = that.grid.GetCell(that.locationCell.Row + dH, that.locationCell.Column + dV);
                    if (checkCell.HasUnit)
                    {
                        return false;
                    }
                break;
                case "r":
                    dH++;
                    checkCell = that.grid.GetCell(that.locationCell.Row + dH, that.locationCell.Column + dV);
                    if (checkCell.HasUnit)
                    {
                        return false;
                    }
                break;
                case "u":
                    dV--;
                    checkCell = that.grid.GetCell(that.locationCell.Row + dH, that.locationCell.Column + dV);
                    if (checkCell.HasUnit)
                    {
                        return false;
                    }
                break;
                case "d":
                    dV++;
                    checkCell = that.grid.GetCell(that.locationCell.Row + dH, that.locationCell.Column + dV);
                    if (checkCell.HasUnit)
                    {
                        return false;
                    }
                break;

            }
        }
        return true;
    });

    UnitGrid.Prop("PruneMoveHints", function(cells)
    {
        var that = this;
        prunedCells = [];
        movePaths = [];
        //that.CellToMovePathMap = [];
        for (var i = 0; i < cells.length; i++)
        {
            var cell = cells[i];
            var up = (cell.Column - that.locationCell.Column) <= 0 ? true : false;
            var left = (cell.Row - that.locationCell.Row) <= 0 ? true : false;
            var movesH = Math.abs(cell.Row - that.locationCell.Row);
            var movesV = Math.abs(cell.Column - that.locationCell.Column);
            var movePattern = [];
            for (var j = 0; j < movesH; j++)
            {
                if (left)
                {
                    movePattern.push("l");
                }
                else
                {
                    movePattern.push("r");
                }
            }
            for (var k = 0; k < movesV; k++)
            {
                if (up)
                {
                    movePattern.push("u");
                }
                else
                {
                    movePattern.push("d");
                }
            }

            var allPossiblePermutaionsOfMovePattern = Global.permutator(movePattern);
            for (var h = 0; h < allPossiblePermutaionsOfMovePattern.length; h++)
            {
                var pattern = allPossiblePermutaionsOfMovePattern[h];
                if (that.ValidatePath(pattern))
                {
                    that.CellToMovePathMap[cell.Row.toString() + "," + cell.Column.toString()] = pattern;
                    prunedCells.push(cell);
                    break;
                }
            }

        }
        return prunedCells;
    });
    window["UnitGrid"] = UnitGrid;
})();

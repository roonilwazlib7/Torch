(function(){

    var WizardAprentice = new Class(function(grid, initialCell, player) {
		;"WizardAprentice";
		this.grid = grid;
		this.Rectangle = new Pipin.Rectangle(initialCell.Rectangle.x, initialCell.Rectangle.y, initialCell.Rectangle.width, initialCell.Rectangle.height);
		this.PlayerIsInControl = false;
		this.locationCell = initialCell;
		this.locationCell.HasUnit = true;

		this.movesToGo = this.moveRange;

        this.player = player;

        that.locationCell.unit = this;

    });

    WizardAprentice.Inherits(Unit);

    WizardAprentice.Override("moveRange", 2);
    WizardAprentice.Override("power", 2);
    WizardAprentice.Override("strength", 1);

    WizardAprentice.Override("Load", function()
    {
        var that = this;
        WizardAprentice.Assets = {};
        WizardAprentice.Assets.DrawTexture = pipin.LoadTexture("../Game/Art/Units/Demons/WizardAprenticeTexture.png");
    });

    window["WizardAprentice"] = WizardAprentice;



})();

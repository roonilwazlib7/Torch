(function(){

    var ElvenArcher = new Class(function(grid, initialCell, player) {
		;"ElvenArcher";
		this.grid = grid;
		this.Rectangle = new Pipin.Rectangle(initialCell.Rectangle.x, initialCell.Rectangle.y, initialCell.Rectangle.width, initialCell.Rectangle.height);
		this.PlayerIsInControl = false;
		this.locationCell = initialCell;
		this.locationCell.HasUnit = true;

		this.movesToGo = this.moveRange;

        this.player = player;

        that.locationCell.unit = this;

    });

    ElvenArcher.Inherits(Unit);

    ElvenArcher.Override("moveRange", 2);
    ElvenArcher.Override("power", 2);
    ElvenArcher.Override("strength", 1);

    ElvenArcher.Override("Load", function()
    {
        var that = this;
        ElvenArcher.Assets = {};
        ElvenArcher.Assets.DrawTexture = pipin.LoadTexture("../Game/Art/Units/Demons/ElvenArcherTexture.png");
    });

    window["ElvenArcher"] = ElvenArcher;



})();

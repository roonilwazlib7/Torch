(function(){

    var ElvenScout = new Class(function(grid, initialCell, player) {
		;"ElvenScout";
		this.grid = grid;
		this.Rectangle = new Pipin.Rectangle(initialCell.Rectangle.x, initialCell.Rectangle.y, initialCell.Rectangle.width, initialCell.Rectangle.height);
		this.PlayerIsInControl = false;
		this.locationCell = initialCell;
		this.locationCell.HasUnit = true;

		this.movesToGo = this.moveRange;

        this.player = player;

        that.locationCell.unit = this;

    });

    ElvenScout.Inherits(Unit);

    ElvenScout.Override("moveRange", 2);
    ElvenScout.Override("power", 2);
    ElvenScout.Override("strength", 1);

    ElvenScout.Override("Load", function()
    {
        var that = this;
        ElvenScout.Assets = {};
        ElvenScout.Assets.DrawTexture = pipin.LoadTexture("../Game/Art/Units/Demons/ElvenScoutTexture.png");
    });

    window["ElvenScout"] = ElvenScout;



})();

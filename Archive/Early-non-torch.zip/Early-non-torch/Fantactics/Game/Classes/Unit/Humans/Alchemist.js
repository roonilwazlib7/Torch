(function(){

    var Alchemist = new Class(function(grid, initialCell, player) {
		;"Alchemist";
		this.grid = grid;
		this.Rectangle = new Pipin.Rectangle(initialCell.Rectangle.x, initialCell.Rectangle.y, initialCell.Rectangle.width, initialCell.Rectangle.height);
		this.PlayerIsInControl = false;
		this.locationCell = initialCell;
		this.locationCell.HasUnit = true;

		this.movesToGo = this.moveRange;

        this.player = player;
        this.DrawParams = {alpha:1,rotation:0};

        this.PlayerTitle = "Alchemist";
        this.locationCell.unit = this;
        this.HintGridCell = Unit.Assets.HintGridCell;
        this.AttackHintCellTexture = Unit.Assets.AttackHintCellTexture;
        this.DrawTexture = Alchemist.Assets.DrawTexture;

    });

    Alchemist.Inherits(Unit);

    Alchemist.Override("moveRange", 5);
    Alchemist.Override("power", 2);
    Alchemist.Override("strength", 1);

    Alchemist.Override("Load", function()
    {
        var that = this;
        Alchemist.Assets = {};
        Alchemist.Assets.DrawTexture = pipin.LoadTexture("../Game/Art/Units/Demons/AlchemistTexture.png");
    });

    window["Alchemist"] = Alchemist;



})();

(function(){

    var Defender = new Class(function(grid, initialCell, player) {
		;"Defender";
		this.grid = grid;
		this.Rectangle = new Pipin.Rectangle(initialCell.Rectangle.x, initialCell.Rectangle.y, initialCell.Rectangle.width, initialCell.Rectangle.height);
		this.PlayerIsInControl = false;
		this.locationCell = initialCell;
		this.locationCell.HasUnit = true;

		this.movesToGo = this.moveRange;

        this.player = player;
        this.DrawParams = {alpha:1,rotation:0};

        this.PlayerTitle = "Defender";
        this.locationCell.unit = this;
        this.HintGridCell = Unit.Assets.HintGridCell;
        this.AttackHintCellTexture = Unit.Assets.AttackHintCellTexture;
        this.DrawTexture = Defender.Assets.DrawTexture;

    });

    Defender.Inherits(Unit);

    Defender.Override("moveRange", 5);
    Defender.Override("power", 2);
    Defender.Override("strength", 1);

    Defender.Override("Load", function()
    {
        var that = this;
        Defender.Assets = {};
        Defender.Assets.DrawTexture = pipin.LoadTexture("../Game/Art/Units/Demons/DefenderTexture.png");
    });

    window["Defender"] = Defender;



})();

(function(){

    var FootMan = new Class(function(grid, initialCell, player) {
		;"FootMan";
		this.grid = grid;
		this.Rectangle = new Pipin.Rectangle(initialCell.Rectangle.x, initialCell.Rectangle.y, initialCell.Rectangle.width, initialCell.Rectangle.height);
		this.PlayerIsInControl = false;
		this.locationCell = initialCell;
		this.locationCell.HasUnit = true;

		this.movesToGo = this.moveRange;

        this.player = player;
        this.DrawParams = {alpha:1,rotation:0};

        this.PlayerTitle = "FootMan";
        this.locationCell.unit = this;
        this.HintGridCell = Unit.Assets.HintGridCell;
        this.AttackHintCellTexture = Unit.Assets.AttackHintCellTexture;
        this.DrawTexture = FootMan.Assets.DrawTexture;

    });

    FootMan.Inherits(Unit);

    FootMan.Override("moveRange", 5);
    FootMan.Override("power", 2);
    FootMan.Override("strength", 1);

    FootMan.Override("Load", function()
    {
        var that = this;
        FootMan.Assets = {};
        FootMan.Assets.DrawTexture = pipin.LoadTexture("../Game/Art/Units/Demons/FootManTexture.png");
    });

    window["FootMan"] = FootMan;



})();

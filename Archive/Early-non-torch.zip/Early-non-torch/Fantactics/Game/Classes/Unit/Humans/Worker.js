(function(){

    var Worker = new Class(function(grid, initialCell, player) {
		;"Worker";
		this.grid = grid;
		this.Rectangle = new Pipin.Rectangle(initialCell.Rectangle.x, initialCell.Rectangle.y, initialCell.Rectangle.width, initialCell.Rectangle.height);
		this.PlayerIsInControl = false;
		this.locationCell = initialCell;
		this.locationCell.HasUnit = true;

		this.movesToGo = this.moveRange;

        this.player = player;
        this.DrawParams = {alpha:1,rotation:0};

        this.PlayerTitle = "Worker";
        this.locationCell.unit = this;
        this.HintGridCell = Unit.Assets.HintGridCell;
        this.AttackHintCellTexture = Unit.Assets.AttackHintCellTexture;
        this.DrawTexture = Worker.Assets.DrawTexture;

    });

    Worker.Inherits(Unit);

    Worker.Override("moveRange", 5);
    Worker.Override("power", 2);
    Worker.Override("strength", 1);

    Worker.Override("Load", function()
    {
        var that = this;
        Worker.Assets = {};
        Worker.Assets.DrawTexture = pipin.LoadTexture("../Game/Art/Units/Demons/WorkerTexture.png");
    });

    window["Worker"] = Worker;



})();

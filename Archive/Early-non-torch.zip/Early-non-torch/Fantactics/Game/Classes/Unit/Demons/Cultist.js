(function(){

    var Cultist = new Class(function(grid, initialCell, player) {
		;"Cultist";
		this.grid = grid;
		this.Rectangle = new Pipin.Rectangle(initialCell.Rectangle.x, initialCell.Rectangle.y, initialCell.Rectangle.width, initialCell.Rectangle.height);
		this.PlayerIsInControl = false;
		this.locationCell = initialCell;
		this.locationCell.HasUnit = true;

		this.movesToGo = this.moveRange;

        this.player = player;
        this.DrawParams = {alpha:1,rotation:0};

        this.PlayerTitle = "Cultist";
        this.locationCell.unit = this;
        this.HintGridCell = Unit.Assets.HintGridCell;
        this.AttackHintCellTexture = Unit.Assets.AttackHintCellTexture;
        this.DrawTexture = Cultist.Assets.DrawTexture;

    });

    Cultist.Inherits(Unit);

    Cultist.Override("moveRange", 5);
    Cultist.Override("power", 2);
    Cultist.Override("strength", 1);

    Cultist.Override("Load", function()
    {
        var that = this;
        Cultist.Assets = {};
        Cultist.Assets.DrawTexture = pipin.LoadTexture("../Game/Art/Units/Demons/CultistTexture.png");
    });

    window["Cultist"] = Cultist;



})();

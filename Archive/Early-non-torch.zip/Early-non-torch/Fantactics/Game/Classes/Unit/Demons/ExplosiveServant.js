(function(){

    var ExplosiveServant = new Class(function(grid, initialCell, player) {
		;"ExplosiveServant";
		this.grid = grid;
		this.Rectangle = new Pipin.Rectangle(initialCell.Rectangle.x, initialCell.Rectangle.y, initialCell.Rectangle.width, initialCell.Rectangle.height);
		this.PlayerIsInControl = false;
		this.locationCell = initialCell;
		this.locationCell.HasUnit = true;

		this.movesToGo = this.moveRange;

        this.player = player;

        that.locationCell.unit = this;

    });

    ExplosiveServant.Inherits(Unit);

    ExplosiveServant.Override("moveRange", 2);
    ExplosiveServant.Override("power", 2);
    ExplosiveServant.Override("strength", 1);

    ExplosiveServant.Override("Load", function()
    {
        var that = this;
        ExplosiveServant.Assets = {};
        ExplosiveServant.Assets.DrawTexture = pipin.LoadTexture("../Game/Art/Units/Demons/ExplosiveServantTexture.png");
    });

    window["ExplosiveServant"] = ExplosiveServant;



})();

(function(){

    var Zombie = new Class(function(grid, initialCell, player) {
		;"Zombie";
		this.grid = grid;
		this.Rectangle = new Pipin.Rectangle(initialCell.Rectangle.x, initialCell.Rectangle.y, initialCell.Rectangle.width, initialCell.Rectangle.height);
		this.PlayerIsInControl = false;
		this.locationCell = initialCell;
		this.locationCell.HasUnit = true;

		this.movesToGo = this.moveRange;

        this.player = player;

        that.locationCell.unit = this;

    });

    Zombie.Inherits(Unit);

    Zombie.Override("moveRange", 2);
    Zombie.Override("power", 2);
    Zombie.Override("strength", 1);

    Zombie.Override("Load", function()
    {
        var that = this;
        Zombie.Assets = {};
        Zombie.Assets.DrawTexture = pipin.LoadTexture("../Game/Art/Units/Demons/ZombieTexture.png");
    });

    window["Zombie"] = Zombie;



})();

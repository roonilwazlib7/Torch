(function(){

    var DwarvenKing = new Class(function(grid, initialCell, player) {
		;"DwarvenKing";
		this.grid = grid;
		this.Rectangle = new Pipin.Rectangle(initialCell.Rectangle.x, initialCell.Rectangle.y, initialCell.Rectangle.width, initialCell.Rectangle.height);
		this.PlayerIsInControl = false;
		this.locationCell = initialCell;
		this.locationCell.HasUnit = true;

		this.movesToGo = this.moveRange;

        this.player = player;

        that.locationCell.unit = this;

    });

    DwarvenKing.Inherits(Unit);

    DwarvenKing.Override("moveRange", 2);
    DwarvenKing.Override("power", 2);
    DwarvenKing.Override("strength", 1);

    DwarvenKing.Override("Load", function()
    {
        var that = this;
        DwarvenKing.Assets = {};
        DwarvenKing.Assets.DrawTexture = pipin.LoadTexture("../Game/Art/Units/Demons/DwarvenKingTexture.png");
    });

    window["DwarvenKing"] = DwarvenKing;



})();

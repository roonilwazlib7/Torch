(function(){

    var DwarvenAxeman = new Class(function(grid, initialCell, player) {
		;"DwarvenAxeman";
		this.grid = grid;
		this.Rectangle = new Pipin.Rectangle(initialCell.Rectangle.x, initialCell.Rectangle.y, initialCell.Rectangle.width, initialCell.Rectangle.height);
		this.PlayerIsInControl = false;
		this.locationCell = initialCell;
		this.locationCell.HasUnit = true;

		this.movesToGo = this.moveRange;

        this.player = player;

        that.locationCell.unit = this;

    });

    DwarvenAxeman.Inherits(Unit);

    DwarvenAxeman.Override("moveRange", 2);
    DwarvenAxeman.Override("power", 2);
    DwarvenAxeman.Override("strength", 1);

    DwarvenAxeman.Override("Load", function()
    {
        var that = this;
        DwarvenAxeman.Assets = {};
        DwarvenAxeman.Assets.DrawTexture = pipin.LoadTexture("../Game/Art/Units/Demons/DwarvenAxemanTexture.png");
    });

    window["DwarvenAxeman"] = DwarvenAxeman;



})();

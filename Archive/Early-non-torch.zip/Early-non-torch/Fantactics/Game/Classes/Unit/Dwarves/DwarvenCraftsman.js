(function(){

    var DwarvenCraftsman = new Class(function(grid, initialCell, player) {
		;"DwarvenCraftsman";
		this.grid = grid;
		this.Rectangle = new Pipin.Rectangle(initialCell.Rectangle.x, initialCell.Rectangle.y, initialCell.Rectangle.width, initialCell.Rectangle.height);
		this.PlayerIsInControl = false;
		this.locationCell = initialCell;
		this.locationCell.HasUnit = true;

		this.movesToGo = this.moveRange;

        this.player = player;

        that.locationCell.unit = this;

    });

    DwarvenCraftsman.Inherits(Unit);

    DwarvenCraftsman.Override("moveRange", 2);
    DwarvenCraftsman.Override("power", 2);
    DwarvenCraftsman.Override("strength", 1);

    DwarvenCraftsman.Override("Load", function()
    {
        var that = this;
        DwarvenCraftsman.Assets = {};
        DwarvenCraftsman.Assets.DrawTexture = pipin.LoadTexture("../Game/Art/Units/Demons/DwarvenCraftsmanTexture.png");
    });

    window["DwarvenCraftsman"] = DwarvenCraftsman;



})();

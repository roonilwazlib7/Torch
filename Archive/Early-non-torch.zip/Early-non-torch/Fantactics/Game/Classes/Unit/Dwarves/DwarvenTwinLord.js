(function(){

    var DwarvenTwinLord = new Class(function(grid, initialCell, player) {
		;"DwarvenTwinLord";
		this.grid = grid;
		this.Rectangle = new Pipin.Rectangle(initialCell.Rectangle.x, initialCell.Rectangle.y, initialCell.Rectangle.width, initialCell.Rectangle.height);
		this.PlayerIsInControl = false;
		this.locationCell = initialCell;
		this.locationCell.HasUnit = true;

		this.movesToGo = this.moveRange;

        this.player = player;

        that.locationCell.unit = this;

    });

    DwarvenTwinLord.Inherits(Unit);

    DwarvenTwinLord.Override("moveRange", 2);
    DwarvenTwinLord.Override("power", 2);
    DwarvenTwinLord.Override("strength", 1);

    DwarvenTwinLord.Override("Load", function()
    {
        var that = this;
        DwarvenTwinLord.Assets = {};
        DwarvenTwinLord.Assets.DrawTexture = pipin.LoadTexture("../Game/Art/Units/Demons/DwarvenTwinLordTexture.png");
    });

    window["DwarvenTwinLord"] = DwarvenTwinLord;



})();

(function(){

    var GoblinTank = new Class(function(grid, initialCell, player) {
		;"GoblinTank";
		this.grid = grid;
		this.Rectangle = new Pipin.Rectangle(initialCell.Rectangle.x, initialCell.Rectangle.y, initialCell.Rectangle.width, initialCell.Rectangle.height);
		this.PlayerIsInControl = false;
		this.locationCell = initialCell;
		this.locationCell.HasUnit = true;

		this.movesToGo = this.moveRange;

        this.player = player;
        this.DrawParams = {alpha:1,rotation:0};

        this.PlayerTitle = "GoblinTank";
        this.locationCell.unit = this;
        this.HintGridCell = Unit.Assets.HintGridCell;
        this.AttackHintCellTexture = Unit.Assets.AttackHintCellTexture;
        this.DrawTexture = GoblinTank.Assets.DrawTexture;

    });

    GoblinTank.Inherits(Unit);

    GoblinTank.Override("moveRange", 5);
    GoblinTank.Override("power", 2);
    GoblinTank.Override("strength", 1);

    GoblinTank.Override("Load", function()
    {
        var that = this;
        GoblinTank.Assets = {};
        GoblinTank.Assets.DrawTexture = pipin.LoadTexture("../Game/Art/Units/Demons/GoblinTankTexture.png");
    });

    window["GoblinTank"] = GoblinTank;



})();

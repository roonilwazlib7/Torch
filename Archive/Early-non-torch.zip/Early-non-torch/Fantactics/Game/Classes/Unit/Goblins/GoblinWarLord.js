(function(){

    var GoblinWarLord = new Class(function(grid, initialCell, player) {
		;"GoblinWarLord";
		this.grid = grid;
		this.Rectangle = new Pipin.Rectangle(initialCell.Rectangle.x, initialCell.Rectangle.y, initialCell.Rectangle.width, initialCell.Rectangle.height);
		this.PlayerIsInControl = false;
		this.locationCell = initialCell;
		this.locationCell.HasUnit = true;

		this.movesToGo = this.moveRange;

        this.player = player;
        this.DrawParams = {alpha:1,rotation:0};

        this.PlayerTitle = "GoblinWarLord";
        this.locationCell.unit = this;
        this.HintGridCell = Unit.Assets.HintGridCell;
        this.AttackHintCellTexture = Unit.Assets.AttackHintCellTexture;
        this.DrawTexture = GoblinWarLord.Assets.DrawTexture;

    });

    GoblinWarLord.Inherits(Unit);

    GoblinWarLord.Override("moveRange", 5);
    GoblinWarLord.Override("power", 2);
    GoblinWarLord.Override("strength", 1);

    GoblinWarLord.Override("Load", function()
    {
        var that = this;
        GoblinWarLord.Assets = {};
        GoblinWarLord.Assets.DrawTexture = pipin.LoadTexture("../Game/Art/Units/Demons/GoblinWarLordTexture.png");
    });

    window["GoblinWarLord"] = GoblinWarLord;



})();

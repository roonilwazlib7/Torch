(function(){

    var GoblinRusher = new Class(function(grid, initialCell, player) {
		;"GoblinRusher";
		this.grid = grid;
		this.Rectangle = new Pipin.Rectangle(initialCell.Rectangle.x, initialCell.Rectangle.y, initialCell.Rectangle.width, initialCell.Rectangle.height);
		this.PlayerIsInControl = false;
		this.locationCell = initialCell;
		this.locationCell.HasUnit = true;

		this.movesToGo = this.moveRange;

        this.player = player;
        this.DrawParams = {alpha:1,rotation:0};

        this.PlayerTitle = "GoblinRusher";
        this.locationCell.unit = this;
        this.HintGridCell = Unit.Assets.HintGridCell;
        this.AttackHintCellTexture = Unit.Assets.AttackHintCellTexture;
        this.DrawTexture = GoblinRusher.Assets.DrawTexture;

    });

    GoblinRusher.Inherits(Unit);

    GoblinRusher.Override("moveRange", 5);
    GoblinRusher.Override("power", 2);
    GoblinRusher.Override("strength", 1);

    GoblinRusher.Override("Load", function()
    {
        var that = this;
        GoblinRusher.Assets = {};
        GoblinRusher.Assets.DrawTexture = pipin.LoadTexture("../Game/Art/Units/Demons/GoblinRusherTexture.png");
    });

    window["GoblinRusher"] = GoblinRusher;



})();

(function(){

    var GoblinBruiser = new Class(function(grid, initialCell, player) {
		;"GoblinBruiser";
		this.grid = grid;
		this.Rectangle = new Pipin.Rectangle(initialCell.Rectangle.x, initialCell.Rectangle.y, initialCell.Rectangle.width, initialCell.Rectangle.height);
		this.PlayerIsInControl = false;
		this.locationCell = initialCell;
		this.locationCell.HasUnit = true;

		this.movesToGo = this.moveRange;

        this.player = player;
        this.DrawParams = {alpha:1,rotation:0};

        this.PlayerTitle = "GoblinBruiser";
        this.locationCell.unit = this;
        this.HintGridCell = Unit.Assets.HintGridCell;
        this.AttackHintCellTexture = Unit.Assets.AttackHintCellTexture;
        this.DrawTexture = GoblinBruiser.Assets.DrawTexture;

    });

    GoblinBruiser.Inherits(Unit);

    GoblinBruiser.Override("moveRange", 5);
    GoblinBruiser.Override("power", 2);
    GoblinBruiser.Override("strength", 1);

    GoblinBruiser.Override("Load", function()
    {
        var that = this;
        GoblinBruiser.Assets = {};
        GoblinBruiser.Assets.DrawTexture = pipin.LoadTexture("../Game/Art/Units/Demons/GoblinBruiserTexture.png");
    });

    window["GoblinBruiser"] = GoblinBruiser;



})();

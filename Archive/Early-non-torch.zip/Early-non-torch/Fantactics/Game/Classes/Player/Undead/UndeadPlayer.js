(function(){

    var UndeadPlayer = new Class(function()
    {
        ;"UndeadPlayer";
    });

    UndeadPlayer.Inherits(Player);

    window["UndeadPlayer"] = UndeadPlayer;

})();

(function(){

    var DwarfPlayer = new Class(function()
    {
        ;"DwarfPlayer";
    });

    DwarfPlayer.Inherits(Player);

    window["DwarfPlayer"] = DwarfPlayer;

})();

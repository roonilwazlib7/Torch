(function(){

    var ElfPlayer = new Class(function()
    {
        ;"ElfPlayer";
        this.PlayerType = "ElfPlayer";
    });

    ElfPlayer.Inherits(Player);

    window["ElfPlayer"] = ElfPlayer;

})();

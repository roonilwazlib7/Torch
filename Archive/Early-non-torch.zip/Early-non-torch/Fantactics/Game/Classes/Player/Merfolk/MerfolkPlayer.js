(function(){

    var MerfolkPlayer = new Class(function()
    {
        ;"MerfolkPlayer";
    });

    MerfolkPlayer.Inherits(Player);

    window["MerfolkPlayer"] = MerfolkPlayer;

})();

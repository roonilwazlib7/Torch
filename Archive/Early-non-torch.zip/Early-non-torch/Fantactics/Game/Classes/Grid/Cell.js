(function(){

	var Cell = new Class(function(rectangle, row, column, terrain)
	{
		this.Rectangle = rectangle;
		this.Row = row;
		this.Column = column;
		this.Terrain = Terrain;
	});

	Cell.Prop("HasUnit", false);
	Cell.Prop("terrainType", "");
	Cell.Prop("unit", null);

	window["Cell"] = Cell;

})();

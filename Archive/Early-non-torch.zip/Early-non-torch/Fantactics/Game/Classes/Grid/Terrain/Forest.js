(function(){

    var Forest = new Class(function()
    {
        ;"Forest";
    });

    Forest.Inherits(Terrain);

    window["Forest"] = Forest;

})();

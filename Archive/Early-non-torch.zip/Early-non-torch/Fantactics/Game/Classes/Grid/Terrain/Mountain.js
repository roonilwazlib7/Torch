(function(){

    var Mountain = new Class(function()
    {
        ;"Mountain";
        this.DrawTexture = Mountain.Assets.MountainTexture;
    });

    Mountain.Inherits(Terrain);

    Mountain.Prop("Load", function()
    {
        var that = this;
        Mountain.Assets = {};
        Mountain.Assets.MountainTexture = pipin.LoadTexture("../Game/Art/Terrain/Mountain/MountainTexture.png");
    });

    
    window["Mountain"] = Mountain;

})();

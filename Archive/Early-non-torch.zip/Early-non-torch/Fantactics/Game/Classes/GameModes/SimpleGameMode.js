
(function(){

	var SimpleGameMode = new Class(function(grid) //Maybe make a new player within instead?
	{
		;"SimpleGameMode";

		//Class.Assure(player1, "Player");
		//Class.Assure(player2, "Player");

		this.p2Texture = pipin.LoadTexture("../Game/Art/player2.png;1;1");
		this.p1Texture = pipin.LoadTexture("../Game/Art/player1.png;1;1");
		this.ElvenArcherTexture = pipin.LoadTexture("../Game/Art/Units/Elves/ElvenArcherTexture.png");
		this.FootManTexture = pipin.LoadTexture("../Game/Art/Units/Humans/FootManTexture.png");

		this.grid = grid;
	});



	SimpleGameMode.Prop("turnCount", 0);
	SimpleGameMode.Prop("playerInControl", null);
	SimpleGameMode.Prop("playerNotInControl", null);
	SimpleGameMode.Prop("ui", null);

	SimpleGameMode.Prop("lockTime", 0);


	SimpleGameMode.Prop("CheckIfUnitIsSelected", function()
	{
		var that = this;
		if (that.player1.UnitIsSelected() || that.player2.UnitIsSelected())
		{
			return true;
		}
		else
		{
			return false;
		}
	});


		//control functions
	SimpleGameMode.Prop("LockAndWait", function()
	{

	});
	SimpleGameMode.Prop("SwitchControl", function()
	{
		var that = this;
		that.turnCount++;
		that.playerNotInControl.TakeControl();
		that.playerInControl.GiveUpControl();

		var newInControlPlayer = that.playerNotInControl;
		var newNotInControlPlayer = that.playerInControl;

		that.playerInControl = newInControlPlayer;
		that.playerNotInControl = newNotInControlPlayer;
	});
	SimpleGameMode.Prop("CheckControl", function()
	{
		var that = this;
		if (that.playerInControl.TurnIsDone() && that.lockTime >= 1000)
		{
			that.SwitchControl();
			that.lockTime = 0;
		}
		else if (that.playerInControl.TurnIsDone())
		{
			that.lockTime += pipin.deltaTime;
		}
	});
	SimpleGameMode.Prop("Control",  function()
	{
		var that = this;
		that.CheckControl();
			//any other items related to the control of the game
	});

	//public non-functions


	//public functions
	SimpleGameMode.Prop("Load", function()
	{
		var that = this;

		SimpleGameModeLoader.Load();

		for (var i = 0; i < that.grid.Cells.length; i++)
		{
			var c = that.grid.Cells[i];
			c.Terrain = new Mountain();
		}

		that.player1 = new WizardPlayer(that.grid);
		that.player2 = new DemonPlayer(that.grid);

		that.player1.color = "blue";
		that.player2.color = "red";

		that.player1.Load();
		that.player2.Load();

		var PlayerTwoUnits =
		[
			new Cultist(that.grid, that.grid.GetCell(6,4), that.player2)/*,
			new ExplosiveServant(that.grid, that.grid.GetCell(4,2), that.player2),
			new Legion(that.grid, that.grid.GetCell(6,1), that.player2),
			new LordOfDeath(that.grid, that.grid.GetCell(8, 1), that.player2),
			new Zombie(that.grid, that.grid.GetCell(4,4), that.player2)*/
		];

		var PlayerOneUnits =
		[
			new Loyalist(that.grid, that.grid.GetCell(4,4), that.player1)/*,
			new GrandWizard(that.grid, that.grid.GetCell(1,3), that.player1),
			new WizardAprentice(that.grid, that.grid.GetCell(1,5), that.player1)*/
		];


		that.player2.Units = PlayerTwoUnits;
		that.player1.Units = PlayerOneUnits;

		that.player1.TakeControl();
		that.ui = new UI(that.grid);

		that.playerInControl = that.player1;
		that.playerNotInControl = that.player2;
	});

	SimpleGameMode.Prop("Draw", function()
	{
		var that = this;
		that.grid.Draw();
		that.player1.Draw();
		that.player2.Draw();

		pipin.canvas.fillText("It is " + that.playerInControl.PlayerType + "'s turn", 10, 25);
		if (that.CheckIfUnitIsSelected())
		{
			that.ui.DrawBottomUIMenu();
		}
	});

	SimpleGameMode.Prop("Update", function()
	{
		var that = this;
		that.player1.Update();
		that.player2.Update();
		that.ui.Update();
		that.Control();
	});


	window["SimpleGameMode"] = SimpleGameMode;

})();

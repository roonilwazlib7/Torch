/*
*	game.js
*
*	Main file for the game,
*	contains the main Draw and Update loops
*/


var Game;
var pipin;




$(document).ready(function(){
	//TODO clean this up
	pipin = new Pipin("gameCanvas");

	var test = new Test();

	var grid = new Grid(25);
	grid.Load();




	var gameMode = new SimpleGameMode(grid);

	window["gameMode"] = gameMode;
	window["HintTexture"] = pipin.LoadTexture("../Game/Art/HintBackgroundTexture.png");



	var
		Load = function()
		{
			gameMode.Load();
		},

		Draw = function()
		{
			gameMode.Draw();
			test.Draw();
		},

		Update = function()
		{
			gameMode.Update();
		};

	Game = new Pipin.Game(pipin, Load, Draw, Update);

	pipin.LoadGame(Game);
	pipin.Run();

});

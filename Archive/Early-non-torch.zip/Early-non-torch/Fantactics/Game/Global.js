window["Global"] = {
  //maybe jump out as soon as a valid path to the cell is found
  //to improve performance
  permutator: function(inputArr) {
  var results = [];
  var patternDoneAlreadyMap = [];

  function permute(arr, memo) {
    var cur, memo = memo || [];

    for (var i = 0; i < arr.length; i++) {
      cur = arr.splice(i, 1);
      if (arr.length === 0) {
        if (!patternDoneAlreadyMap[memo.concat(cur).toString()])
        {
          results.push(memo.concat(cur));
          patternDoneAlreadyMap[memo.concat(cur).toString()] = true;
        }

      }
      permute(arr.slice(), memo.concat(cur));
      arr.splice(i, 0, cur[0]);
    }

    return results;
  }

  return permute(inputArr);
}

};

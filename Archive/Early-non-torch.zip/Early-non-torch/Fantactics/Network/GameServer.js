var GameServer =
{
  serverId: 0,
  clients: [],

  Init: function(socket)
  {
    var that = this;
    that.connectedPlayer1 = false;
    that.connectedPlayer2 = false;
    that.clients = [];
    that.serverId = that.GenerateId();
    that.socket = socket;
    that.StartExchange();

    socket.on("player_connection", function(data)
    {
        that.clients.push({});
        console.log(data);
        socket.emit("log", "Player Connected At: " + new Date().toISOString());
        socket.emit("log", "Players Connected: " + that.clients.length);
    });

  },

  GenerateId: function()
  {
    return new Date().getMilliseconds() * Math.random() * 10;
  },

  ConnectClient: function(client, game) //maybe a player
  {
    var that = this;
    that.clients.push(client);
  },
  Yell: function()
  {
      var that = this;
      //that.socket.emit("yell", that.clients);
      that.socket.emit("test1", {});
  },
  ConnectPlayer1: function()
  {
      var that = this;
      that.socket.on("connect_player_1", function(data)
      {
          if (!that.connectedPlayer1)
          {
              console.log("Connected Player1");
              that.connectedPlayer1 = true;
              //do the connecting
          }
          else
          {
              console.log("Refused Player 1 Connection");
          }
      });
      that.socket.on("connect_player_2", function(data)
      {
          if (!that.connectedPlayer2)
          {
              console.log("Connected Player2");
              that.connectedPlayer2 = true;
              //do the connecting
          }
          else
          {
              console.log("Refused Player 2 Connection");
          }
      });
  },
  StartExchange: function()
  {
    var that = this;
    //var fps = that.clients[0].game.fps//should be lowest one
    that.socket.on("connect_client", function(data)
    {
        that.clients[data.id] = data;
        console.log(that.clients);
    });

    that.socket.on("unit_push", function(data){
        console.log(data);
    });

    that.ConnectPlayer1();

    setInterval(function(){
      that.Yell();
    }, 1000/60);
  },
}


var app = require('http').createServer(handler)
var io = require('socket.io')(app);
var fs = require('fs');

app.listen(8080);



function handler (req, res) {
  fs.readFile(__dirname + '/index.html',
  function (err, data) {
    if (err) {
      res.writeHead(500);
      return res.end('Error loading index.html');
    }

    res.writeHead(200);
    res.end(data);
  });
}

io.on('connection', function (socket) {

    GameServer.Init(socket); //should have multiple sockets

    console.log("...connection...");

    setInterval(function()
    {
        socket.emit("log", "This is a health test at: " + new Date().toISOString());

    }, 5000);


});

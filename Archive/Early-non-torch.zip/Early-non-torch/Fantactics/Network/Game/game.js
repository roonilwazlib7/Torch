
var game = new Torch.Game("canvas", 1280, 720, "fantactics");
game.observer = new Observer();
var gameMode;
var screenAdjust = {};
screenAdjust.RightMax = 1280;
screenAdjust.LeftMax = 0;
screenAdjust.BottomMax = 720;
screenAdjust.TopMax = 0;

function Load()
{
    game.Load.Texture("Art/UI/background_bottom.png", "ui_bottom_background");
    game.Load.Texture("Art/health_bar.png", "health");
    game.Load.Texture("Art/place_background.png", "place_background");
    game.Load.Texture("Art/GridCell.png", "cell");
    game.Load.Texture("Art/plain_cell.png", "plain");
    game.Load.Texture("Art/forest_cell.png", "forest");
    game.Load.Texture("Art/MountainTile.png", "mountain");
    game.Load.Texture("Art/grid_cell_hidden.png", "hidden_cell");
    game.Load.Texture("Art/ActiveGridCell.png", "active_cell");
    game.Load.Texture("Art/AttackHintCellTexture.png", "hint_cell_attack");
    game.Load.Texture("Art/HintGridCell.png", "hint_cell");
    game.Load.TextureSheet("Art/HintGridCellSheet.png", "hint_cell_sheet", 280, 210, 70, 70);
    game.Load.TextureSheet("Art/combat_explosion.png", "explosion", 512, 64, 64, 64);
    game.Load.TextureSheet("Art/blue_magic.png", "blue_magic", 512, 64, 64, 64);
    game.Load.TextureSheet("Art/goblin_theif-death.png", "goblin_theif_death", 704, 64, 64, 64);

    game.Load.Texture("Art/goblin_theif.png", "goblin_bruiser");
    game.Load.Texture("Art/blue_shell_goblin_thief.png", "goblin_theif_shell");
    game.Load.Texture("Art/Units/Goblins/goblin_rusher.png", "goblin_rusher");
    game.Load.Texture("Art/Units/Goblins/GoblinTank.png", "goblin_tank");
    game.Load.Texture("Art/Units/Goblins/goblin_war_lord.png", "goblin_war_lord");
    game.Load.Texture("Art/Units/Wizards/grand_wizard.png", "grand_wizard");

    game.Load.Texture("Art/Units/ELves/elven_archer.png", "elven_archer");
    game.Load.Texture("Art/Units/ELves/elven_herbalist.png", "elven_herbalist");
    game.Load.Texture("Art/Units/ELves/elven_scout.png", "elven_scout");
    game.Load.Texture("Art/Units/ELves/ElvenRanger.png", "elven_ranger");

    game.Load.TextureSheet("Art/blood.png", "blood", 768, 100, 128, 128);

    game.Load.Texture("Art/fortress.png", "fortress");
}
function Update()
{
    gameMode.Update();
    // if (game.Mouse.x >= screenAdjust.RightMax)
    // {
    //     game.Viewport.x -= 15;
    //     screenAdjust.RightMax += 0;
    // }
    // if (game.Mouse.x <= screenAdjust.LeftMax)
    // {
    //     game.Viewport.x += 15;
    // }
    // if (game.Mouse.y >= screenAdjust.BottomMax)
    // {
    //     game.Viewport.y -= 15;
    // }
    // if (game.Mouse.y <= screenAdjust.TopMax)
    // {
    //     game.Viewport.y += 15;
    // }
}

function Draw()
{

}

function Init()
{
    game.Clear("black");
    var grid = new Grid(64, game);
    gameMode = new SandboxNetworkGame(grid);
    //gameMode = new SandBoxGameMode(grid);
    //gameMode.Init();
    window["mode"] = gameMode;
}

game.Start(Load, Update, Draw, Init);

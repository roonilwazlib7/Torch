var BottomMenu =
{
    Constructor: function()
    {
        this.spriteStack = [];
        this.Init();
    },
    Init: function()
    {
        var that = this;
        that.background = that.GenerateSprite(0,0,"ui_bottom_background",true);
    },
    GenerateSprite: function(x,y,image,background)
    {
        var that = this;
        var originX = 0;
        var originY = 520;
        var sprite = new Torch.Sprite(x+originX,y+originY);
        sprite.drawIndex = background ? 10 : 11;
        game.Add(sprite);
        sprite.Bind.Texture(image);
        sprite.Fixed();
        if (!background) that.spriteStack.push(sprite);
        return sprite;
    },
    GenerateText: function(x,y,text,style,background)
    {
        var that = this;
        var originX = 0;
        var originY = 520;
        var text = new Torch.Text(text, x+originX, y+originY, style );
        game.Add(text);
        text.drawIndex = 20;
        text.Fixed();
        that.spriteStack.push(text);
        return text;
    },
    Empty: function()
    {
        var that = this;
        for (var i = 0; i < that.spriteStack.length; i++)
        {
            game.Remove(that.spriteStack[i]);
        }
    },
    MenuUnit: function(unit)
    {
        var that = this;
        that.Empty();
        that.GenerateText(0,0, "Gold: " + unit.gold,{font: "14px arcade", fillStyle: "yellow"});
        that.GenerateText(0,30, "Player Name: " + unit.player.name,{font: "14px arcade", fillStyle: "white"});
        that.GenerateText(0,60, "Unit Name: " + unit.name,{font: "14px arcade", fillStyle: "white"});
    }
}

BottomMenu = Class(BottomMenu);

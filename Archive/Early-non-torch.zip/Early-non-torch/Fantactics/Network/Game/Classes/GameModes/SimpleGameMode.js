(function()
{
    var GameState = {};
    GameState.Play = "PLAY";
    GameState.PlacePlayers = "PLACEPLAYERS";
    GameState.Player2Place = "PLAYER2PLACE";

    var GoblinUnitList =
    [
        {unitType: "GoblinBruiser", name: "Goblin Bruiser", description: "A basic and fierce goblin unit", texture: "goblin_bruiser", recruitCost: 2},
        {unitType: "GoblinRusher", name: "Goblin Rusher", description: "An extremely quick goblin unit", texture: "goblin_rusher", recruitCost: 1},
        {unitType: "GoblinTank", name: "Goblin Tank", description: "An extremely sturdy goblin unit", texture: "goblin_tank", recruitCost: 2},
        {unitType: "GoblinWarLord", name: "Goblin War Lord", description: "A special goblin unit", texture: "goblin_war_lord", recruitCost: 3}
    ]

    var ElfUnitList =
    [
        {unitType: "ElvenArcher", name: "Elven Archer", description: "A swift ranged Elf", texture: "elven_archer", recruitCost: 1},
        {unitType: "ElvenHerbalist", name: "Elven Herbalist", description: "A a wise elf", texture: "elven_herbalist", recruitCost: 3},
        {unitType: "ElvenScout", name: "Elven Scout", description: "An extremely swift elf", texture: "elven_scout", recruitCost: 2},
        {unitType: "ElvenRanger", name: "Elven Ranger", description: "A mighty elf warrior", texture: "elven_ranger", recruitCost: 3}
    ]

    var SimpleGameMode = new Class(function(grid)
    {
        ;"SimpleGameMode";
        this.grid = grid;
        this.info = new Torch.Text("", 100, 50, {font: "20px Consolas", fillStyle: "red"} );
        game.Add(this.info);
        this.info.Fixed();

        this.gameState = GameState.PlacePlayers;
        this.placedUnits = [];
        this.SANDBOX = true;

        window.bottomMenu = new BottomMenu();
        this.count = 0;
        var that = this;
        window.socket.on("yell", function(data){
            console.log(data);
        });
        window.socket.emit("player_connection", {});
    });



    SimpleGameMode.Inherits(SandBoxGameMode);
    SimpleGameMode.Prop("SpritesToDump", []);

    SimpleGameMode.Prop("playerOneIsReadyToStart", false);

    SimpleGameMode.Prop("BuildUnitOption", function(placePosition, listUnit, player, recruitmentTotalText)
    {
        var that = this;
        var storedListPos = {x: placePosition.x, y: placePosition.y};
        var dragSprite = new Torch.Sprite(placePosition.x, placePosition.y);
        var lSprite = new Torch.Sprite(placePosition.x, placePosition.y);

        var lSpriteText = new Torch.Text(listUnit.name, placePosition.x, placePosition.y + 80, {font: "14px pixel", fillStyle: "black"} );
        var lSpriteTextDescription = new Torch.Text(listUnit.description, placePosition.x, placePosition.y + 100, {font: "14px pixel", fillStyle: "black"} );
        var lSpriteTextPower = new Torch.Text("Recruitment Cost: " + listUnit.recruitCost, placePosition.x, placePosition.y + 120, {font: "14px pixel", fillStyle: "red"} );

        lSpriteText.Fixed();
        lSpriteTextDescription.Fixed();
        lSpriteTextPower.Fixed();

        lSprite.drawIndex = lSpriteText.drawIndex = lSpriteTextDescription.drawIndex = lSpriteTextPower.drawIndex = 6;
        lSprite.Fixed();
        dragSprite.drawIndex = 7;

        that.SetUpNewPlacingUnit(storedListPos, listUnit, player, recruitmentTotalText);

        game.Add(lSprite);

        game.Add(lSpriteText);
        game.Add(lSpriteTextDescription);
        game.Add(lSpriteTextPower);

        lSprite.Bind.Texture(listUnit.texture);

        placePosition.y += 130;
        that.SpritesToDump = that.SpritesToDump.concat( [lSprite, lSpriteText, lSpriteTextDescription, lSpriteTextPower] );

    });

    SimpleGameMode.Prop("SetUpNewPlacingUnit", function(placePosition, listUnit, player, recTotal)
    {
        var that = this;
        if (player.recruitPointsLeft - listUnit.recruitCost < 0) return;
        var newDragSprite = new Torch.Sprite(placePosition.x, placePosition.y);
        game.Add(newDragSprite);
        newDragSprite.unitType = listUnit.unitType;
        newDragSprite.Bind.Texture(listUnit.texture);
        newDragSprite.drawIndex = 7;
        newDragSprite.name = listUnit.name;
        newDragSprite.Fixed();
        that.SpritesToDump.push(newDragSprite);

        Torch.Controls.Bind(newDragSprite, "DragDrop", {bringToTop: true, stayOnTop: true, dragFinish: function(sprite){
                if(sprite.touchedCell)
                {
                    sprite.Rectangle.x = sprite.touchedCell.Rectangle.x;
                    sprite.Rectangle.y = sprite.touchedCell.Rectangle.y;
                    sprite.locationCell = sprite.touchedCell;
                    sprite.UnFixed();
                    if (!sprite.placeIndex && sprite.placeIndex != 0)
                    {
                        sprite.placeIndex = player.placedUnits.length;
                        player.placedUnits.push(sprite);
                        player.recruitPointsLeft -= listUnit.recruitCost;
                        recTotal.text = "Recruitment Points Left: " + player.recruitPointsLeft;
                    }
                }
                else
                {
                    game.Remove(sprite);
                }
            }
        });

        newDragSprite.AddUpdate(function(sprite)
        {
            that.grid.Cells.forEach(function(cell)
            {
                touchedCells = [];
                var adjustedRec = {x: sprite.Rectangle.x - game.Viewport.x , y: sprite.Rectangle.y - game.Viewport.y, width: sprite.Rectangle.width, height: sprite.Rectangle.height}

                if (cell.Rectangle.Intersects(adjustedRec))
                {
                    touchedCells.push(cell);
                }
                else
                {
                }
                if (touchedCells[0])
                {
                    sprite.touchedCell = touchedCells[0];
                }
            })
        });

        newDragSprite.Click(function(sprite)
        {
            if (player.recruitPointsLeft - listUnit.recruitCost >= 0 && that.gameState != GameState.Play)
            {
                that.SetUpNewPlacingUnit(placePosition, listUnit, player, recTotal);
            }
        });
    });

    SimpleGameMode.Prop("SetUpUnitPlacingForPlayer", function(player)
    {
        //menu should be fixed
        var that = this;
        var placePosition = {x: 25, y:50};
        var recruitmentTotalText = new Torch.Text("Recruitment Points Left: " + player.recruitPointsLeft, 25, 25, {font: "18px pixel", fillStyle: "black"} );
        game.Add(recruitmentTotalText);
        recruitmentTotalText.drawIndex = 6;
        var background = new Torch.Sprite(0,0);
        game.Add(background);
        background.Bind.Texture("place_background");
        background.drawIndex = 5;
        background.Fixed();
        recruitmentTotalText.Fixed();

        that.SpritesToDump =  that.SpritesToDump.concat( [recruitmentTotalText, background] );

        switch(player.playerType)
        {
            case "Goblin":
                GoblinUnitList.forEach(function(listUnit)
                {
                    that.BuildUnitOption(placePosition, listUnit, player, recruitmentTotalText);
                });

            break;

            case "Elf":
                ElfUnitList.forEach(function(listUnit)
                {
                    that.BuildUnitOption(placePosition, listUnit, player, recruitmentTotalText);
                });
            break
        }
    });

    SimpleGameMode.Prop("LoadPlayerUnits", function(player)
    {
        var that = this;
        var units = [];
        console.log(player.placedUnits);
        player.placedUnits.forEach(function(placedUnit)
        {
            switch (placedUnit.unitType)
            {
                case "GoblinBruiser":
                    units.push( new GoblinBruiser(that.grid, placedUnit.locationCell, player, that.grid.game) );
                break;

                case "GoblinRusher":
                    units.push( new GoblinRusher(that.grid, placedUnit.locationCell, player, that.grid.game)  );
                break;

                case "GoblinTank":
                    units.push( new GoblinTank(that.grid, placedUnit.locationCell, player, that.grid.game)  );
                break;

                case "GoblinWarLord":
                    units.push( new GoblinWarLord(that.grid, placedUnit.locationCell, player, that.grid.game)  );
                break;

                case "ElvenArcher":
                    units.push( new ElvenArcher(that.grid, placedUnit.locationCell, player, that.grid.game)  );
                break;

                case "ElvenHerbalist":
                    units.push( new ElvenHerbalist(that.grid, placedUnit.locationCell, player, that.grid.game)  );
                break;

                case "ElvenRanger":
                    units.push( new ElvenRanger(that.grid, placedUnit.locationCell, player, that.grid.game)  );
                break;

                case "ElvenScout":
                    units.push( new ElvenScout(that.grid, placedUnit.locationCell, player, that.grid.game)  );
                break
            }
        });
        player.Units = units;
    });

    SimpleGameMode.Prop("InitPlayers", function()
    {
        var that = this;
        that.player1.UnKnownCells = that.grid.Cells;
        that.player2.UnKnownCells = that.grid.Cells;

        if (!that.SANDBOX) that.LoadPlayerUnits(that.player2);

		that.player1.TakeControl();

		that.playerInControl = that.player1;
		that.playerNotInControl = that.player2;

    });

    SimpleGameMode.Override("Init", function()
    {
        var that = this;

        that.grid.Init();

        that.player1 = new GoblinPlayer(that.grid);
        that.player2 = new ElfPlayer(that.grid);

        that.player2.grid = that.grid;
        that.player1.grid = that.grid;

        that.player1.name = "Player1";
        that.player2.name = "Player2";

        that.player1.color = "blue";
        that.player2.color = "red";
        that.player1.placingUnits = true;
        that.player1.recruitPointsLeft = that.player2.recruitPointsLeft = 10;
        Torch.debuggedItem = that;

        if (!that.SANDBOX)
        {
            that.SetUpUnitPlacingForPlayer(that.player1);
        }
        var p1Unit = new GoblinBruiser(that.grid, that.grid.GetCell(3,3), that.player1, that.grid.game);
        that.sandboxPlayerOneUnits = [ p1Unit ];
        window.testUnit = p1Unit;
        that.sandboxPlayerTwoUnits = [ new GrandWizard(that.grid, that.grid.GetCell(6,6), that.player2, that.grid.game) ];

        window.fortress = new Fortress(that.grid.GetCell(2,2));
    });

    SimpleGameMode.Override("Update", function()
    {
        var that = this;

        var unitData = [];
        for (var i = 0; i < that.player1.Units.length; i++)
        {
            var obj = {
                Rectangle:that.player1.Units[i].Rectangle
            }
            unitData.push(obj);
        }

        window.socket.emit("unit_push", unitData);

        if (that.SANDBOX && !that._sandboxed)
        {
            console.log("..1")
            //that.Init();

            that.gameState = GameState.Play;
            that.player1.Units = that.sandboxPlayerOneUnits;
            that.player2.Units = that.sandboxPlayerTwoUnits;
            that._sandboxed = true;

            that.InitPlayers();
        }
        if (game.Keys.L.down && that.gameState == GameState.Player2Place)
        {
            var unClean = true;
            for (var i = 0; i < that.SpritesToDump.length; i++)
            {
                game.Remove(that.SpritesToDump[i]);
            }

            that.gameState = GameState.Play
            that.InitPlayers();

        }
        else if (game.Keys.Q.down && that.gameState == GameState.PlacePlayers)
        {

            that.gameState = GameState.Player2Place;
            for (var i = 0; i < that.SpritesToDump.length; i++)
            {
                game.Remove(that.SpritesToDump[i]);
            }
            that.placedUnits = [];
            that.SpritesToDump = [];

            that.LoadPlayerUnits(that.player1);

            that.SetUpUnitPlacingForPlayer(that.player2);
            game.Viewport.x -= 1000;

        }
        switch (that.gameState) {
            case GameState.Play:
                that.info.text = "It is " + that.playerInControl.name + "'s turn";
                that.player1.Update();
                that.player2.Update();
                that.Control();
            break;


        }
    });

    window.SimpleGameMode = SimpleGameMode;
})();

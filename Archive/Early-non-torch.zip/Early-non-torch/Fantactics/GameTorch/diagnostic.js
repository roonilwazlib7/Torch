var Diagnostic = {};

Diagnostic.PeekObject = function(obj)
{
    var html = "";
    for (key in obj)
    {
        html += "<label style = 'font-weight:bold'>" + key + ": </label>" + "<label>" + obj[key] + "</label><br /><br />";
    }
    return html;
}

Diagnostic.PeekSprites = function(start)
{
    var html = "";
    for (var i = start; i < game.spriteList.length; i++)
    {
        html += Diagnostic.PeekObject(game.spriteList[i]);
    }
    myWindow = window.open("", "MsgWindow", "width=200, height=100");
    myWindow.document.write(html);
}

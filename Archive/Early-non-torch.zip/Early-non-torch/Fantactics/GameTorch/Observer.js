var Observer = function(){};

(function(observer)
{

    observer.noise = [];

    observer.Listen = function(tag, listener, action)
    {
        var index = this.noise.length;
        var sound = { tag:tag, listener:listener, index:index, action:action };
        this.noise.push(sound);
    };

    observer.Ignore = function(sound)
    {
        this.noise = this.noise.slice( sound.index - 1, 1 );
    };

    observer.Notify = function(tag, speaker, params)
    {
        for (var i = 0; i < this.noise.length; i++)
        {
            if (this.noise[i].tag == tag)
            {
                this.noise[i].action(speaker, this.noise[i].listener, params);
            }
        }
    }

})(Observer.prototype);


//Tags
UNIT_IS_DONE= "unitdonethisturn";

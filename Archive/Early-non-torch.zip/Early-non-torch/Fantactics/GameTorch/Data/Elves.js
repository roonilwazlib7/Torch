Data.Elves=
{
    "Race": "Elves",
    "Units": {
        "ElvenArcher": {
            "name": "ElvenArcher",
            "health": 200,
            "origHealth": 200,
            "moveRange": 4,
            "attackRange": 2,
            "power": 30,
            "strength": 20
        },
        "ElvenRanger": {
            "name": "ElvenRanger",
            "health": 10,
            "moveRange": 300,
            "attackRange": 1,
            "power": 30,
            "strength": 10
        },
        "ElvenHerbalist": {
            "name": "ElvenHerbalist",
            "health": 10,
            "moveRange": 300,
            "attackRange": 1,
            "power": 30,
            "strength": 10
        },
        "ElvenScout": {
            "name": "ElvenScout",
            "health": 10,
            "moveRange": 300,
            "attackRange": 1,
            "power": 30,
            "strength": 10
        }
    }
}

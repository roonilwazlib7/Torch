var UnitEvents =
{
    ClearHintCells: function()
    {
        var that = this;
        for (var i = 0; i < that.MoveHintCells.length; i++)
        {
            that.MoveHintCells[i].Reveal();
            that.MoveHintCells[i].Click(null);
        }
        for (var i = 0; i < that.AttackHintCells.length; i++)
        {
            that.AttackHintCells[i].Reveal();
            that.AttackHintCells[i].Click(null);
        }

        that.MoveHintCells = [];
        that.AttackHintCells = [];
    },

    BindEvents: function()
    {
        var that = this;
        that.Click(function(sprite)
        {
            that.HandleMouseMove();
            game.Viewport.Center(sprite);
            bottomMenu.MenuUnit(sprite);
        });

        that.ClickAway(function(sprite)
        {
            that.ClearHintCells();
        });
    }
};

UnitEvents = Class(UnitEvents);

(function(){

    var ElvenScout = new Class(function(grid, initialCell, player, game) {
		;"ElvenScout";

        Unit.Construct(this, grid, initialCell, player, game, "elven_scout");

        this.PlayerTitle = "ElvenScout";

    });

    ElvenScout.Inherits(Unit);

    ElvenScout.Override("moveRange", 3);
    ElvenScout.Override("power", 20);
    ElvenScout.Override("strength", 5);
    ElvenScout.Override("health", 30)


    window["ElvenScout"] = ElvenScout;



})();

(function(){

    var ElvenRanger = new Class(function(grid, initialCell, player, game) {
		;"ElvenRanger";

        Unit.Construct(this, grid, initialCell, player, game, "elven_ranger");

        this.PlayerTitle = "ElvenRanger";

    });

    ElvenRanger.Inherits(Unit);

    ElvenRanger.Override("moveRange", 3);
    ElvenRanger.Override("power", 30);
    ElvenRanger.Override("strength", 10);
    ElvenRanger.Override("health", 35);
    ElvenRanger.Override("attackRange", 4);


    window["ElvenRanger"] = ElvenRanger;



})();

(function(){

    var GoblinTank = new Class(function(grid, initialCell, player, game) {
		;"GoblinTank";

        Unit.Construct(this, grid, initialCell, player, game, "goblin_tank");

        this.PlayerTitle = "GoblinTank";

    });

    GoblinTank.Inherits(Unit);

    GoblinTank.Override("moveRange", 3);
    GoblinTank.Override("power", 10);
    GoblinTank.Override("strength", 5);
    GoblinTank.Override("health", 30)


    window["GoblinTank"] = GoblinTank;

})();

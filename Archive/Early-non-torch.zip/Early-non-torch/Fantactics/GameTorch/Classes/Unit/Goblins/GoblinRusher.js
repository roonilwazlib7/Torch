(function(){

    var GoblinRusher = new Class(function(grid, initialCell, player, game) {
		;"GoblinRusher";

        Unit.Construct(this, grid, initialCell, player, game, "goblin_rusher");

        this.PlayerTitle = "GoblinRusher";

    });

    GoblinRusher.Inherits(Unit);

    GoblinRusher.Override("moveRange", 5);
    GoblinRusher.Override("power", 15);
    GoblinRusher.Override("strength", 5);
    GoblinRusher.Override("health", 20)


    window["GoblinRusher"] = GoblinRusher;



})();

var UnitCombat =
{
    AttackUnitInCell: function(cell)
    {
        var that = this;
        var unitInCell = cell.unit;
        if ( that.GetDistance(cell) > that.attackRange || that.attackedThisTurn ) return;

        that.StageCombat(that, unitInCell);
    },

    StageCombat: function(attacker, defender)
    {
        attacker.AttackEffect(defender, function()
        {
            var damage = attacker.power - defender.strength;
            if (damage < 0) damage = 0;

            defender.health -= damage;

            if (defender.health > 0)
            {
                defender.DefendEffect(attacker, function()
                {
                    var damage = defender.power - attacker.strength;
                    if (damage < 0) damage = 0;

                    attacker.health -= damage;

                    attacker.attackedThisTurn = true;
                    attacker.movedThisTurn = true;
                });
            }
        });
    }
};


UnitCombat = Class(UnitCombat);

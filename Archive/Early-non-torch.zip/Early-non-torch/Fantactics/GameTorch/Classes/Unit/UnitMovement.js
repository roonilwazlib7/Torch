var UnitMovement =
{
    MouseMoveToCell: function(cell)
    {
        var that = this;
		if (cell.HasUnit) return;
		var path = that.CellToMovePathMap[cell.Row.toString() + "," + cell.Column.toString()];

		that.Move({x: cell.Rectangle.x, y: cell.Rectangle.y}, 3, function(sprite)
		{
		},Torch.Tween.Linear);

		that.movesToGo -= (that.GetDistance(cell));

		that.locationCell.HasUnit = false;
		that.locationCell.unit = null;
		that.locationCell = cell;
		that.locationCell.HasUnit = true;
		that.locationCell.unit = that;


		that.grid.Cells.forEach(function(cell)
		{
			// if (cell.Seen[that.player.name])
			// {
			// 	cell.Reveal();
			// }
			// cell.Click(null);
		});


		if (that.movesToGo <= 0)
		{
			that.movedThisTurn = true;
		}

		that.selected = false;
    },

    HandleMouseMove: function()
    {
        var that = this;
		//should be decoupled
		if ( (that.movedThisTurn && that.attackedThisTurn) || !that.player.HasControl) return;
		that.selected = true;
		that.SetHints();
    }
}

UnitMovement = Class(UnitMovement);

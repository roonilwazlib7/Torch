Items.RustyKnife =
{
    itemType: ItemType.Passive,
    cost: 10,
    //passive items just boost stats,
    //so here are some stat boosts
    power: 5
}

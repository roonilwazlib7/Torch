Items.RingOfPower =
{
    itemType: ItemType.Active,

    power: 50,

    init: function(sprite)
    {
        sprite.RingOfPower = {};
        sprite.RingOfPower.coolDownTracker = 0;
        sprite.RingOfPower.coolDown = 10;
        sprite.RingOfPower.invisable = false;
    },

    startTurn: function(sprite)
    {
        if (sprite.RingOfPower.coolDownTracker > 0) sprite.RingOfPower.coolDownTracker--;
    },

    endTurn: function(sprite)
    {

    },

    update: function(sprite)
    {
        if (game.Keys.Q.down && sprite.selected && !sprite.RingOfPower.invisable)
        {
            //make it invisable
            //some sort of effect?
            sprite.RingOfPower.invisable = true;
            sprite.RingOfPower.coolDownTracker = sprite.RingOfPower.coolDown;
            sprite.DrawParams.alpha = 0.5;
        }
    }
}

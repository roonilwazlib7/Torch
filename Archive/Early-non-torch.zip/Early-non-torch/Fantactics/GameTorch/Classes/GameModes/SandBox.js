var Sandbox =
{
    Constructor: function(grid)
    {
        this.grid = grid;
        this.info = new Torch.Text("", 100, 50, {font: "20px Consolas", fillStyle: "red"} );
        game.Add(this.info);
        this.info.Fixed();
        this.placedUnits = [];
        this.SANDBOX = true;
    },

    InitPlayers: function()
    {
        var that = this;
        that.player1.UnKnownCells = that.grid.Cells;
        that.player2.UnKnownCells = that.grid.Cells;

        that.player1.TakeControl();

        that.playerInControl = that.player1;
        that.playerNotInControl = that.player2;
    },

    Init: function()
    {
        var that = this;

        that.grid.Init();

        that.player1 = new GoblinPlayer(that.grid);
        that.player2 = new ElfPlayer(that.grid);

        that.player2.grid = that.grid;
        that.player1.grid = that.grid;

        that.player1.name = "Player1";
        that.player2.name = "Player2";

        that.player1.color = "blue";
        that.player2.color = "red";
        that.player1.placingUnits = true;
        that.player1.recruitPointsLeft = that.player2.recruitPointsLeft = 10;
        Torch.debuggedItem = that;

        that.sandboxPlayerOneUnits = [ new GoblinBruiser(that.grid, that.grid.GetCell(5,5), that.player1, that.grid.game) ];
        that.sandboxPlayerTwoUnits = [ new GrandWizard(that.grid, that.grid.GetCell(6,6), that.player2, that.grid.game) ];
        window.fortress = new Fortress(that.grid.GetCell(2,2));
    },

    Update: function()
    {
        var that = this;
        if (!that._sandboxed)
        {
            that.player1.Units = that.sandboxPlayerOneUnits;
            that.player2.Units = that.sandboxPlayerTwoUnits;
            that._sandboxed = true;

            that.InitPlayers();
        }

        that.info.text = "It is " + that.playerInControl.name + "'s turn";
        that.player1.Update();
        that.player2.Update();
        that.Control();

    }
}

Sandbox = Class(Sandbox, "Sandbox");
Sandbox.Extend(SandBoxGameMode);

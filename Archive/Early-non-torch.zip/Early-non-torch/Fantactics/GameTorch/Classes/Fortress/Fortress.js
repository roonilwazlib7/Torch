var Fortress =
{
    Constructor: function(initialCell)
    {
        this.Init(initialCell);
        this.Rectangle.x = initialCell.Rectangle.x;
        this.Rectangle.y = initialCell.Rectangle.y;
        this.drawIndex = 1;
    },

    Init: function(initialCell)
    {
        var that = this;
        that.InitSprite();
        that.Rectangle = new Torch.Rectangle(initialCell.Rectangle.x, initialCell.Rectangle.y, 0, 0);
        game.Add(this);
        this.Bind.Texture("fortress");
        that.locationCell = initialCell;

        that.AddUpdate(that.CheckForUnits);
    },

    CheckForUnits: function(sprite)
    {
        var that = this;
        if (sprite.locationCell.unit && !sprite._stop)
        {
            //alert("fortress now has a unit");
            sprite._stop = true;
        }
    },
}
Fortress = Class(Fortress);
Fortress.Extend(Torch.Sprite);

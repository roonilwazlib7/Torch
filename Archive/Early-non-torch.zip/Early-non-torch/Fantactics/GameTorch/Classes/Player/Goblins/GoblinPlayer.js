(function(){

    var GoblinPlayer = new Class(function()
    {
        ;"GoblinPlayer";
        this.playerType = "Goblin";
        this.placedUnits = [];
        this.SeenCells = [];
        Player.Construct(this);
    });

    GoblinPlayer.Inherits(Player);

    window["GoblinPlayer"] = GoblinPlayer;

})();

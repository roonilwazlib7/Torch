
(function(){

	var Player = new Class(function(playerType, grid) //Maybe make a new player within instead?
	{
		;"Player";
		this.PlayerType = playerType; //consider renaming to playerName
		this.grid = grid;
		this.SeenCells = [];
	});
	Player.Construct = function(player)
	{
		player.SeenCells = [];
	}
	Player.Prop("unitsFinishedCount", 0);
	Player.Prop("HasControl", false);

	Player.Prop("Units", []);
	Player.Prop("placedUnits", []);
	Player.Prop("SeenCells", []);
	Player.Prop("HintGridCell", null);
	Player.Prop('SelectedUnit', null);

	Player.Prop("UnitIsSelected", function()
	{
		var that = this;
		for (var i = 0; i < that.Units.length; i++)
		{
			if (that.Units[i].selected)
			{
				that.SelectedUnit = that.Units[i];
				return true;
			}
		}
		that.SelectedUnit = null;
		return false;
	});

	Player.Prop("TakeControl", function(donePlayer)
	{
		var that = this;
		that.SeenCells = [];
		that.HasControl = true;
		//game.Viewport.x = (1280 / 2) + ( 0 - that.Units[0].sprite.Rectangle.x );// - 100;// + 50;
		game.Viewport.Latch(that.Units[0]);
		//game.Viewport.y = that.Units[0].Rectangle.y - 100;// + 50;
		if (donePlayer != undefined)
		{
		}
		for (var i = 0; i < that.Units.length; i++)
		{
			that.Units[i].StartTurn();
			//that.Units[i].Show();
		}

		for (var i = 0; i < that.Units.length; i++)
		{
			that.SeenCells = that.SeenCells.concat(that.Units[i].CellsInVison);
		}

		for (var i = 0; i < that.SeenCells.length; i++)
		{
			that.SeenCells[i].Bind.Texture("cell");
			that.SeenCells[i].Reveal();
		}
	});

	Player.Prop("GiveUpControl", function()
	{
		var that = this;
		that.HasControl = false;
		for (var i = 0; i < that.Units.length; i++)
		{
			that.Units[i].PlayerIsInControl = false;
			that.Units[i].doneThisTurn = false;
			console.log(that.Units[i].doneThisTurn);
			//that.Units[i].Hide();
		}
		that.SeenCells.forEach(function(cell)
		{
			console.log("hiding");
		});
	});

	Player.Prop("TurnIsDone", function()
	{
		var that = this;
		var unitsDone = 0;
		for (var i = 0; i < that.Units.length; i++)
		{
			var u = that.Units[i];
			if (u.doneThisTurn)
			{
				unitsDone++;
			}
		}
		if (unitsDone == that.Units.length) return true;
		else return false;
	});

	Player.Prop("Load", function()
	{
		var that = this;
	});

	Player.Prop("Draw", function()
	{
		var that = this;
		for (var i = 0; i < that.Units.length; i++)
		{
			if (that.HasControl) that.Units[i].Draw();
		}
	});

	Player.Prop("Update", function()
	{
		var that = this;
		for (var i = 0; i < that.Units.length; i++)
		{
			for (var k = 0; k < that.SeenCells.length; k++)
			{
				if (that.SeenCells[k].HasUnit && that.SeenCells[k].unit.playerName!= that.name && that.Units[i].GetDistance(that.SeenCells[k]) <= that.Units[i].vision)
				{
					that.SeenCells[k].unit.Show();
				}
			}
			for (var j = 0; j < that.grid.Cells.length; j++)
			{
				if ( that.Units[i].GetDistance(that.grid.Cells[j]) <= that.Units[i].vision && !that.grid.Cells[j].Seen[that.name])
				{
					if (!that.grid.Cells[j].Seen[that.name] && that.HasControl)
					{
						that.grid.Cells[j].Reveal();
					}
					that.grid.Cells[j].Seen[that.name] = true;
					that.SeenCells.push(that.grid.Cells[j]);
				}
			}
		}
	});

	window["Player"] = Player;

})();

/*
 $$$$$$\  $$$$$$$\     $$$$$\ $$$$$$$$\  $$$$$$\ $$$$$$$$\       $$$$$$$$\ $$\   $$\ $$\   $$\  $$$$$$\ $$$$$$$$\ $$$$$$\  $$$$$$\  $$\   $$\  $$$$$$\  
$$  __$$\ $$  __$$\    \__$$ |$$  _____|$$  __$$\\__$$  __|      $$  _____|$$ |  $$ |$$$\  $$ |$$  __$$\\__$$  __|\_$$  _|$$  __$$\ $$$\  $$ |$$  __$$\ 
$$ /  $$ |$$ |  $$ |      $$ |$$ |      $$ /  \__|  $$ |         $$ |      $$ |  $$ |$$$$\ $$ |$$ /  \__|  $$ |     $$ |  $$ /  $$ |$$$$\ $$ |$$ /  \__|
$$ |  $$ |$$$$$$$\ |      $$ |$$$$$\    $$ |        $$ |         $$$$$\    $$ |  $$ |$$ $$\$$ |$$ |        $$ |     $$ |  $$ |  $$ |$$ $$\$$ |\$$$$$$\  
$$ |  $$ |$$  __$$\ $$\   $$ |$$  __|   $$ |        $$ |         $$  __|   $$ |  $$ |$$ \$$$$ |$$ |        $$ |     $$ |  $$ |  $$ |$$ \$$$$ | \____$$\ 
$$ |  $$ |$$ |  $$ |$$ |  $$ |$$ |      $$ |  $$\   $$ |         $$ |      $$ |  $$ |$$ |\$$$ |$$ |  $$\   $$ |     $$ |  $$ |  $$ |$$ |\$$$ |$$\   $$ |
 $$$$$$  |$$$$$$$  |\$$$$$$  |$$$$$$$$\ \$$$$$$  |  $$ |         $$ |      \$$$$$$  |$$ | \$$ |\$$$$$$  |  $$ |   $$$$$$\  $$$$$$  |$$ | \$$ |\$$$$$$  |
 \______/ \_______/  \______/ \________| \______/   \__|         \__|       \______/ \__|  \__| \______/   \__|   \______| \______/ \__|  \__| \______/ 

*/
function Ball(rectangle, texture){
	this.rectangle = rectangle;
	this.texture = texture;
	this.Update = Update;
	this.Draw = Draw;
	this.tap = false;
	this.vy = 7;
	this.vx = 7;
	this.trans = false;
	this.alpha = 1;
	this.index = 0;
	this.goBack = false;
	function Update(){
		Move(this);
		Transition(this);
	}
	function Draw(){
		d(this);
	}
	function d(o){
		if (this.trans == false){Draw2(o.texture, o.rectangle);}
		else{
			Draw7(o.texture, o.rectangle.x, o.rectangle.y, o.alpha)
		}
	}
	function Move(o){
		if (o.alpha >= 1){o.rectangle.x += o.vx;}
		if (o.alpha >= 1){o.rectangle.y += o.vy;}

		if (o.rectangle.x <= 0 || o.rectangle.x >= (1280 - o.rectangle.width)){
			o.vx *= -1;
		}
		if (o.rectangle.y <= 0 || o.rectangle.y >= (720 - o.rectangle.height)){
			o.vy *= -1;
		}
		if (o.rectangle.y < 0){
			o.rectangle.y +=  2 *o.vy;
		}
	}
	function Transition(o){
		if (o.alpha < 1){
			o.alpha += 0.01;
		}
		if (o.alpha > 1){
			o.alpha = 1;
		}
	}

}
function Paddle(rectangle, texture){
	this.rectangle = rectangle;
	this.texture = texture;
	this.Update = Update;
	this.Draw = Draw;
	this.human = true;
	function Update(){
		Move(this);
		HandleBall(this);
		UpdateScore();
	}
	function Draw(){
		d(this);
	}
	function d(o){
		Draw3(o.texture, o.rectangle);
	}
	function Move(o){
		o.rectangle.y = mouse.y;
	}
	function HandleBall(o){
		if (Intersects(o.rectangle, ball.rectangle) && ball.tap == false){
			if (ball.rectangle.y <= o.rectangle.y){
				ball.rectangle.y -= 10;
				ball.vy *= -1;	
			}
			if (ball.rectangle.y >= (o.rectangle.y + o.rectangle.height)){
				ball.rectangle.y += 10;
				ball.vy *= -1;
			}
			ball.vx *= -1;
			ball.rectangle.x += ball.vx;
			ball.tap = true;
		}
		if (Intersects(o.rectangle, ball.rectangle) == false){
			ball.tap = false;
		}
		
	}
	function UpdateScore(){
		playerScore = new Score(1000, 50, PlayerScore);
		aiScore = new Score(50, 50, AIScore);
	}
}
function AI_Paddle(rectangle, texture){
	this.rectangle = rectangle;
	this.texture = texture;
	this.Update = Update;
	this.Draw = Draw;
	this.vy = 5;
	function Update(){
		Move(this);
		HandleBall(this);
	}
	function Draw(){
		d(this);
	}
	function d(o){
		Draw3(o.texture, o.rectangle);
	}
	function Move(o){
		o.rectangle.y += o.vy;
		if (o.rectangle.y <= 0 || o.rectangle.y >= (720 - o.rectangle.height)){
			o.vy *= -1;
		}
	}
	function HandleBall(o){
		if (Intersects(o.rectangle, ball.rectangle) && ball.tap == false){
			if (ball.rectangle.y <= o.rectangle.y){
				ball.rectangle.y -= 10;
				ball.vy *= -1;	
			}
			ball.vx *= -1;
			ball.rectangle.x += ball.vx;
			ball.tap = true;
		}
		if (Intersects(o.rectangle, ball.rectangle) == false){
			ball.tap = false;
		}
		
	}
}
function Goal(rectangle, texture, player){
	this.rectangle = rectangle;
	this.texture = texture;
	this.player = player;
	this.Update = Update;
	this.Draw = Draw;
	function Update(){
		HandleBall(this);
	}
	function Draw(){
		d(this);
	}
	function d(o){
		Draw2(o.texture, o.rectangle);
	}
	function HandleBall(o){
		if (Intersects(o.rectangle, ball.rectangle)){
			ball.rectangle.x = 602;
			ball.rectangle.y = 322;
			ball.alpha = 0;
			if (o.player.human){PlayerScore += 1;}
			else{AIScore += 1;}

		}
	}
	
}
function PowerUp(rectangle, texture, effect, generationSeed){
	this.rectangle = rectangle;
	this.texture = texture;
	this.effect = effect;
	this.generationSeed = generationSeed;
	this.Update = Update;
	this.Draw = Draw;
	this.generateCounter = 0;
	this.draw = false;

	function Draw(){
		d(this);
	}
	function d(o){
		Draw2(o.texture, o.rectangle)
	}
	function Update(){
		Handle(this);
	}
	function Handle(o){
		o.generateCounter++;
		if (o.generateCounter >= o.generationSeed){
			if (o.draw == false){
			x = 50 + (1000 * Math.random());
			y = 50 + (500 * Math.random());
			o.rectangle.x = x;
			o.rectangle.y = y;
		}
			o.draw = true;
		}
	}
}
function BigPaddleEffect(){

}
function Score(x, y, text){
	this.x = x;
	this.y = y;
	this.text = text;
	this.Update = Update;
	this.Draw = Draw;
	function Update(){

	}
	function Draw(){
		d(this);
	}
	function d(o){
		DrawText(o.text, o.x, o.y, "red", "20px Impact");
	}

}
/*
$$$$$$$$\ $$\   $$\ $$\   $$\  $$$$$$\ $$$$$$$$\ $$$$$$\  $$$$$$\  $$\   $$\  $$$$$$\  
$$  _____|$$ |  $$ |$$$\  $$ |$$  __$$\\__$$  __|\_$$  _|$$  __$$\ $$$\  $$ |$$  __$$\ 
$$ |      $$ |  $$ |$$$$\ $$ |$$ /  \__|  $$ |     $$ |  $$ /  $$ |$$$$\ $$ |$$ /  \__|
$$$$$\    $$ |  $$ |$$ $$\$$ |$$ |        $$ |     $$ |  $$ |  $$ |$$ $$\$$ |\$$$$$$\  
$$  __|   $$ |  $$ |$$ \$$$$ |$$ |        $$ |     $$ |  $$ |  $$ |$$ \$$$$ | \____$$\ 
$$ |      $$ |  $$ |$$ |\$$$ |$$ |  $$\   $$ |     $$ |  $$ |  $$ |$$ |\$$$ |$$\   $$ |
$$ |      \$$$$$$  |$$ | \$$ |\$$$$$$  |  $$ |   $$$$$$\  $$$$$$  |$$ | \$$ |\$$$$$$  |
\__|       \______/ \__|  \__| \______/   \__|   \______| \______/ \__|  \__| \______/ 

*/
function ChangeBall(){
	if (ball.goBack == false){
		ball.index++;
		if (ball.index >= 8){
			ball.goBack = true;
		}
		ball.texture = ballTextures[ball.index];
	}
	else{
		ball.index--;
		if (ball.index <= 0){
			ball.goBack = false;
		}
		ball.texture = ballTextures[ball.index];
	}
}
function UpdatePowerups(){
	for (var i = 0; i < powerUps.length; i++){
		powerUps[i].Update();
	}
}
function DrawPowerups(){
	for (var i = 0; i < powerUps.length; i++){
		if (powerUps[i].draw){powerUps[i].Draw();}
	}
}
/*
$$\       $$$$$$\   $$$$$$\  $$$$$$$\  $$$$$$\ $$\   $$\  $$$$$$\  
$$ |     $$  __$$\ $$  __$$\ $$  __$$\ \_$$  _|$$$\  $$ |$$  __$$\ 
$$ |     $$ /  $$ |$$ /  $$ |$$ |  $$ |  $$ |  $$$$\ $$ |$$ /  \__|
$$ |     $$ |  $$ |$$$$$$$$ |$$ |  $$ |  $$ |  $$ $$\$$ |$$ |$$$$\ 
$$ |     $$ |  $$ |$$  __$$ |$$ |  $$ |  $$ |  $$ \$$$$ |$$ |\_$$ |
$$ |     $$ |  $$ |$$ |  $$ |$$ |  $$ |  $$ |  $$ |\$$$ |$$ |  $$ |
$$$$$$$$\ $$$$$$  |$$ |  $$ |$$$$$$$  |$$$$$$\ $$ | \$$ |\$$$$$$  |
\________|\______/ \__|  \__|\_______/ \______|\__|  \__| \______/ 

*/
ballTexture = LoadImage("ball.png");
ballTextures = [];
ballTextures[0] = ballTexture;
ballTextures[1] = LoadImage("ball2.png");
ballTextures[2] = LoadImage("ball3.png");
ballTextures[3] = LoadImage("ball4.png");
ballTextures[4] = LoadImage("ball5.png");
ballTextures[5] = LoadImage("ball6.png");
ballTextures[6] = LoadImage("ball7.png");
ballTextures[7] = LoadImage("ball8.png");
ballTextures[8] = LoadImage("ball9.png");

paddleTexture = LoadImage("paddle.png");

backgroundTexture = LoadImage("background.png");

goalTexture = LoadImage("goal.png");
alt_goalTexture = LoadImage("goal_player.png");

BigPaddlePowerupTexture = LoadImage("mushroom.png");
/*
$$\      $$\ $$$$$$$$\ $$\      $$\ $$$$$$$\  $$$$$$$$\ $$$$$$$\   $$$$$$\  
$$$\    $$$ |$$  _____|$$$\    $$$ |$$  __$$\ $$  _____|$$  __$$\ $$  __$$\ 
$$$$\  $$$$ |$$ |      $$$$\  $$$$ |$$ |  $$ |$$ |      $$ |  $$ |$$ /  \__|
$$\$$\$$ $$ |$$$$$\    $$\$$\$$ $$ |$$$$$$$\ |$$$$$\    $$$$$$$  |\$$$$$$\  
$$ \$$$  $$ |$$  __|   $$ \$$$  $$ |$$  __$$\ $$  __|   $$  __$$<  \____$$\ 
$$ |\$  /$$ |$$ |      $$ |\$  /$$ |$$ |  $$ |$$ |      $$ |  $$ |$$\   $$ |
$$ | \_/ $$ |$$$$$$$$\ $$ | \_/ $$ |$$$$$$$  |$$$$$$$$\ $$ |  $$ |\$$$$$$  |
\__|     \__|\________|\__|     \__|\_______/ \________|\__|  \__| \______/                                                                          
*/
ball = new Ball(new Rectangle(50,50,71,69), ballTexture);
paddle = new Paddle(new Rectangle(1000,50,25,200), paddleTexture);
ai_paddle = new AI_Paddle(new Rectangle(200,50,25,200), paddleTexture);

goal1 = new Goal(new Rectangle(0, 210, 30, 300), goalTexture, paddle);
goal2 = new Goal(new Rectangle(1250, 210, 30, 300), alt_goalTexture, ai_paddle);

powerUps = [];
BigPaddlePowerup = new PowerUp(new Rectangle(50, 50, 100, 100), BigPaddlePowerupTexture, BigPaddleEffect, 50);
powerUps[0] = BigPaddlePowerup;

PlayerScore = 0;
playerScore = new Score(0,0, "0");

AIScore = 0;
aiScore = new Score(0,0,"0");
/*
$$\   $$\ $$$$$$$\  $$$$$$$\   $$$$$$\ $$$$$$$$\ $$$$$$$$\ 
$$ |  $$ |$$  __$$\ $$  __$$\ $$  __$$\\__$$  __|$$  _____|
$$ |  $$ |$$ |  $$ |$$ |  $$ |$$ /  $$ |  $$ |   $$ |      
$$ |  $$ |$$$$$$$  |$$ |  $$ |$$$$$$$$ |  $$ |   $$$$$\    
$$ |  $$ |$$  ____/ $$ |  $$ |$$  __$$ |  $$ |   $$  __|   
$$ |  $$ |$$ |      $$ |  $$ |$$ |  $$ |  $$ |   $$ |      
\$$$$$$  |$$ |      $$$$$$$  |$$ |  $$ |  $$ |   $$$$$$$$\ 
 \______/ \__|      \_______/ \__|  \__|  \__|   \________|

*/
function Update(){
	paddle.Update();
	ball.Update();
	ai_paddle.Update();

	goal1.Update();
	goal2.Update();

	ChangeBall();
	UpdatePowerups();
}
/*
$$$$$$$\  $$$$$$$\   $$$$$$\  $$\      $$\ 
$$  __$$\ $$  __$$\ $$  __$$\ $$ | $\  $$ |
$$ |  $$ |$$ |  $$ |$$ /  $$ |$$ |$$$\ $$ |
$$ |  $$ |$$$$$$$  |$$$$$$$$ |$$ $$ $$\$$ |
$$ |  $$ |$$  __$$< $$  __$$ |$$$$  _$$$$ |
$$ |  $$ |$$ |  $$ |$$ |  $$ |$$$  / \$$$ |
$$$$$$$  |$$ |  $$ |$$ |  $$ |$$  /   \$$ |
\_______/ \__|  \__|\__|  \__|\__/     \__|
*/
function Draw(){
	Draw2(backgroundTexture, new Rectangle(0,0,1280,720))
	ball.Draw();
	paddle.Draw();
	ai_paddle.Draw();

	goal1.Draw();
	goal2.Draw();

	playerScore.Draw();
	aiScore.Draw();

	DrawPowerups();
}

game = new GameObject(Update, Draw);
Master = new GameObject(null,null);
Master.Run(game);
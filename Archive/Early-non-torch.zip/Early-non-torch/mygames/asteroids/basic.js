//basic.js
function Rectangle(x , y, width, height){
	this.x = x;
	this.y = y;
	this.width = width;
	this.height = height;
	
}
function _Draw(o, rot){
   

	canvas.drawImage(o.image, o.rectangle.x, o.rectangle.y, o.rectangle.width, o.rectangle.height);
    
	
		
	}
function Draw_Texture(o, rectangle){
		canvas.drawImage(o, rectangle.x, rectangle.y, rectangle.width, rectangle.height);
	}
function Intersects(a, b) {
        if (a.x < (b.x + b.width) && (a.x + a.width) > b.x && a.y < (b.y + b.height) && (a.y + a.height) > b.y){
			return true;
		}
		else return false;
    }
function PlaySound(path){
	var snd = new Audio(path); 
	snd.play();
}
function drawRot(o, rot){
   canvas.save();

    canvas.beginPath();
    // move the rotation point to the center of the rect
    canvas.translate(o.rectangle.x + o.rectangle.width / 2, o.rectangle.y + o.rectangle.height / 2);
    // rotate the rect
    canvas.rotate(rot);

  
	canvas.drawImage(o.image, -o.rectangle.x, -o.rectangle.y, o.rectangle.width, o.rectangle.height);


  

    // restore the context to its untranslated/unrotated state
    canvas.restore();


}
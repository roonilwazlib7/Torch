//gameworld file for the game
var c = document.getElementById("canvas")
canvas = c.getContext("2d");
var difficultyCounter = 0;
var KILLS = 0;
var WAVE = 0;

var WIDTH = c.width;
var HEIGHT = c.height;

function LoadImage(src){
	image = new Image();
	image.src = src;
	return image;
}
function LoadEnemies(amount){
		enemies = [];
		enemyIndex = 0;
		difficultyCounter++;
		WAVE++;
		
		
		for (var i = 0; i < amount; i++){
			var randX = Math.floor((Math.random()*1100)+1);
			if (randX < 100){
				continue;
			}
			en = null;
			var randY = -1 * (Math.floor((Math.random()*1200)+1));
			rec = new Rectangle(randX, randY, 50, 50);
			var randShip = Math.random() * 90;
			if (randShip < 50){
				en = new Enemy(rec, enemyTexture, difficultyCounter);
			}
			else if (randShip >= 50 && randShip < 60){
				en = new Enemy(rec, enemyTexture2, difficultyCounter);
			}
			else{
				en = new Enemy(rec, enemyTexture3, difficultyCounter);
			}
			enemies[enemyIndex] = en;
			enemyIndex++;
			
			
		}
		
	}
function WaveCleared(ens){
	for (var i = 0; i < ens.length; i++){
		if (ens[i].draw){
			return false
		}
	}
	return true;
}

//initialize------------------------>
var dirsHavePlayed = false;
var dirCounter = 0;
//
var player;
var playerTexture;
var playerRec;
var DAMAGE = 1;
//
var bg;
var bgRec1;
var bgRec2;
//
_bulletImage = LoadImage("ims/bullet.png");
//---------------------------------->
var overHeatCounter = 0;
//
menuTex = LoadImage("ims/store_background.png");
elementBackground = LoadImage("ims/store_item_background.png");
item1 = new MenuElement(new Rectangle(5, HEIGHT * 0.2, WIDTH * 0.2, HEIGHT * 0.2), elementBackground);
var elems= [];

menu = new StoreMenu(c, menuTex, new Rectangle(5, 5, 600, 600), elems);

//
playerTexture = LoadImage("ims/player.png");
playerRec = new Rectangle(500, 100, 100, 100);
player = new Player(playerRec, playerTexture, canvas); 
//s
bg = LoadImage("ims/bg.jpg");
bgRec1 = new Rectangle(0, 0, 1280, 700);
bgRec2 = new Rectangle(0, 0, 1280, 700);
//
enemyTexture = LoadImage("ims/enemy.png");
enemyTexture2 = LoadImage("ims/enemy_2.png");
enemyTexture3 = LoadImage("ims/enemy_3.png");
LoadEnemies(50);
enemyExplodeTextures = [];
enemyExplodeTextures[0] = LoadImage("explode/fireball_hit_0001.png");
enemyExplodeTextures[1] = LoadImage("explode/fireball_hit_0002.png");
enemyExplodeTextures[2] = LoadImage("explode/fireball_hit_0003.png");
enemyExplodeTextures[3] = LoadImage("explode/fireball_hit_0004.png");
enemyExplodeTextures[4] = LoadImage("explode/fireball_hit_0005.png");
enemyExplodeTextures[5] = LoadImage("explode/fireball_hit_0006.png");
enemyExplodeTextures[6] = LoadImage("explode/fireball_hit_0007.png");
enemyExplodeTextures[7] = LoadImage("explode/fireball_hit_0008.png");
enemyExplodeTextures[8] = LoadImage("explode/fireball_hit_0009.png");
//
healthImage = LoadImage("ims/health.png");
damageImage = LoadImage("ims/damage.png");
healthPowerUp = new PowerUp(new Rectangle(100, 100, 75, 52),healthImage , HealthEffect, player, 1000);
damagePowerUp = new PowerUp(new Rectangle(200, 200, 130, 50),damageImage , DamageBoostEffect, player, 6000);
dir = new Directions();
function Update(){
	//update menu here
	//
	overHeatCounter++;
	if (overHeatCounter > 500){ 
		overHeatCounter = 0;
		player.shotsForOverHeat = 0;
	}
	//
	bgRec1.y++;
	bgRec2 = new Rectangle(bgRec1.x, bgRec1.y - 700, 1280, 700);
	if (bgRec1.y > 700){
		bgRec1 = new Rectangle(0, 0, 1280, 700);
	}
	//
	player.Update();
	player.hits = hits;
	//
	AddBulletPlayer(player);
	for (var i = 0; i < bullets.length; i++){
		bullets[i].Update();
	}
	//
	for (var i = 0; i < enemies.length; i++){
		enemies[i].Update();
		if (Intersects(enemies[i].rectangle, player.rectangle)){
			enemies[i].health = 0;
			
			if (enemies[i].hasDamagedPlayer == false && enemies[i].draw){
					player.health -= 1;
					enemies[i].hasDamagedPlayer = true;
			}
			
		}
		if (enemies[i].rectangle.y > 700 && enemies[i].draw){
			player.isDead = true;
			
		}
	}
	if (WaveCleared(enemies)){
		LoadEnemies(50);
	}
	//
	healthPowerUp.Update();
	damagePowerUp.Update();
}
function Draw(){
	Draw_Texture(bg, bgRec1);
	Draw_Texture(bg, bgRec2);
	//
	
	//
	if (player.isDead == false){
		for (var i = 0; i < bullets.length; i++){
			if (bullets[i].draw){
			_Draw(bullets[i]);
			}
		}
	}
	//
	if (player.isDead == false){
		_Draw(player, Math.PI / 2);
		//draw player info----
		canvas.fillStyle = "green";
		canvas.font = "bold 20px Imapct";
		hs = String(player.percent).split(".");
		he = hs[0];
	
		ss = String(player.finalScore).split(".");
		se = ss[0];
		
		var overHeat = player.shotsForOverHeat / overHeatCounter;
		var overHeatPercent = (overHeat / 0.1) * 100;
		if (overHeatPercent >= 100) player.overHeating = true;
		else {
			player.overHeating = false;
		}
		canvas.fillText("Health: " + he + "%", 1050, 25);
		canvas.fillStyle = "purple";
		canvas.fillText("Accuracy: " + player.accuracy + "%", 1050, 50);
		canvas.fillStyle = "gold";
		canvas.fillText("Score: " + se , 1050, 75)
		canvas.fillStyle = "red";
		if (player.overHeating == false){
			canvas.fillText("Laser Core Use: " + Math.floor(overHeatPercent) + "%", 1050, 100);
		}
		else{
			canvas.fillText("OVERHEATING!", 1050, 100);
		}
	//
		for (var i = 0; i < enemies.length; i++){
			if (enemies[i].draw){
				_Draw(enemies[i]);
				if (enemies[i].draw && enemies[i].health != enemies[i].maxHealth){
					canvas.fillStyle = "red";
					canvas.font = "bold 10px Imapct";
					num = enemies[i].health/enemies[i].maxHealth;
					num = Math.round(num * 100);
				
					canvas.fillText(num + "%", enemies[i].rectangle.x, enemies[i].rectangle.y + 50);
				}
			}
		}
	//
		if (healthPowerUp.draw){
			_Draw(healthPowerUp);
		}
		if (damagePowerUp.draw){
			_Draw(damagePowerUp);
		}
	}
	//
	canvas.fillStyle = "red";
	canvas.font = "bold 10px Impact";
	canvas.fillText("Wave: " + WAVE, 600, 690);
	canvas.fillText("Kills: " + KILLS, 650, 690);
	//
	if (player.isDead){
		canvas.font = "bold 30px Impact";
		canvas.fillText("GAME OVER", 200, 300);
	}
	//
	/* _Draw(menu);
	for (var i = 0; i < menu.elements.length; i++){
		var els = menu.elements;
		_Draw(els[i]);
	} */
}

function RUN(){
	canvas.clearRect(0, 0, 10000, 10000);
	
	if (dirsHavePlayed)
	{
		Draw();
		Update();
	}
	else
	{
	if (dirCounter < 200){
			Draw_Texture(dir.background1, new Rectangle(0, 0, 500, 500));
		}
	else if (dirCounter > 200){
		Draw_Texture(dir.directions, new Rectangle(0, 0, 1280, 1000));
	}
	if (dirCounter > 500){
		dirsHavePlayed = true;
	}
	dirCounter++;
	}
	
	
	
}

setInterval(RUN, 1000/60);

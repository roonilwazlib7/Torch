
function KeysDown(o){
    document.onkeydown = function (e) {
        var e = window.event || e

        if (e.keyCode == 83 || e.keyCode == 115) {
            o.MoveDown = true;
        }
        if (e.keyCode == 87 || e.keyCode == 119) {
            o.MoveUp = true;
        }
        if (e.keyCode == 68 || e.keyCode == 100) {
            o.MoveRight = true;
        }
        if (e.keyCode == 65 || e.keyCode == 97) {
            o.MoveLeft = true;
        }

        
    }

}
function KeysUp(o) {
    document.onkeyup = function (e) {
        var e = window.event || e
        if (e.keyCode == 83 || e.keyCode == 115) {
            o.MoveDown = false;
        }
        if (e.keyCode == 87 || e.keyCode == 119) {
            o.MoveUp = false;
        }
        if (e.keyCode == 68 || e.keyCode == 100) {
            o.MoveRight = false;
        }
        if (e.keyCode == 65 || e.keyCode == 97) {
            o.MoveLeft = false;
        }
    }
}
function Player(rectangle, image, canvas){
	this.rectangle = rectangle;
	this.image = image;
	this.health = 10;
	this.percent = 0;
	this.MoveDown = false;
	this.MoveUp = false;
	this.MoveRight = false;
	this.MoveLeft = false;
	this.canvas = canvas;
	this.Update = Update;
	this.baseScore = 0;
	this.finalScore = 0;
	this.accuracy = 0;
	this.hits = 0;
	this.shots = 0;
	this.shotsForOverHeat = 0;
	this.isDead = false;
	this.overHeating = false;
	function Update(){
		KeysDown(this);
		KeysUp(this);
		Move(this);
		DrawInfo(this);
		CheckIfDead(this);
		UpdateAccuracy(this);
		GetScore(this);
	}
	
	function Move(o){//param here is the player
	
    if (o.MoveDown == true) {
        if (!(o.rectangle.y >= 600) /*its image height*/) {
            o.rectangle.y += 10;
        }
        
    }
    if (o.MoveUp == true) {
        if (!(o.rectangle.y <= 0)) {
            o.rectangle.y -= 10;
        }
        
    }
    if (o.MoveRight == true) {
        if (o.rectangle.x < 1180) {
            o.rectangle.x += 10;
        }
    }
    if (o.MoveLeft == true) {
        if (!(o.rectangle.x <= 0)) {
            o.rectangle.x -= 10;
        }
    }
	}
	function DrawInfo(o){
		h = o.health;
		percent = h / 10;
		percent *= 100;
		o.percent = percent;
	}
	function UpdateAccuracy(o){
		if (o.shots > 0){
			raw = o.hits / o.shots;
			percent = Math.round(raw * 100);
			o.accuracy = percent;
		}
		else {
			o.accuracy = 100;
		}
	}
	function GetScore(o){
		baseScore = o.baseScore;
		acBonus = Math.round(o.accuracy * 100);
		score = baseScore * o.acBonus;
		o.finalScore = o.baseScore * (o.accuracy / 10);
	}
	function CheckIfDead(o){
		if (o.health <= 0){
			o.isDead = true;
			
		}
	}
}

